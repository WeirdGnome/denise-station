#!/usr/bin/env python3
"""Denise Station - a clean-room Amiga game launcher using Amiberry (AppImage).

GTK4 + libadwaita front end. Logic lives in denise_core.py, scraping in denise_scraper.py,
translations in denise_i18n.py + locale/*.po.
"""
import collections
import hashlib
import json
from pathlib import Path
import os
import random
import shlex
import shutil
import subprocess
import sys
import threading
from concurrent.futures import ThreadPoolExecutor
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import gi

gi.require_version("GdkPixbuf", "2.0")
gi.require_version("Pango", "1.0")
import gtk4_compat  # noqa: E402,F401  (must come before the first use of Gtk)
from gtk4_compat import Adw, Gdk, GLib, Gio, GObject, Gtk, mg, popup_menu, menu_button_model  # noqa: E402
gi.require_version("Graphene", "1.0")
from gi.repository import GdkPixbuf, Graphene, Gsk, Pango  # noqa: E402
from gtk4_compat import children as children_of  # noqa: E402

import denise_core as core  # noqa: E402
import denise_i18n as i18n  # noqa: E402
import denise_scraper as scraper  # noqa: E402
import setup_wizard  # noqa: E402
import whdload_dialog  # noqa: E402
from denise_i18n import _  # noqa: E402


THUMB_W, THUMB_H = 120, 160
DETAIL_W = 290            # width of the panel on the right
DEBUG = "--debug" in sys.argv or bool(os.environ.get("DENISE_DEBUG"))
DEBUG_LOG = core.DATA_DIR / "debug.log"
_dbg_file = None


def dlog(msg):
    """Diagnostic line in debug.log (only with --debug or DENISE_DEBUG=1)."""
    if _dbg_file:
        _dbg_file.write("%.3f %s\n" % (time.time() % 100000, msg))
        _dbg_file.flush()


def dtimed(name):
    """Decorator: log how long a method takes when it exceeds 20 ms."""
    def deco(fn):
        if not DEBUG:
            return fn

        def wrapper(*a, **kw):
            t = time.perf_counter()
            try:
                return fn(*a, **kw)
            finally:
                ms = (time.perf_counter() - t) * 1000
                if ms >= 20:
                    dlog("%-16s %6.0f ms" % (name, ms))
        return wrapper
    return deco


def start_debug():
    """Open debug.log, log main-loop stalls (> 250 ms) and dump the Python stack when the UI is stuck for 1.5 s."""
    global _dbg_file
    if not DEBUG:
        return
    import faulthandler
    core.DATA_DIR.mkdir(parents=True, exist_ok=True)
    _dbg_file = open(DEBUG_LOG, "w", encoding="utf-8")
    dlog("Denise Station %s, debug log started (python %s, GTK %d.%d, session %s)" % (
        core.VERSION, sys.version.split()[0], Gtk.get_major_version(), Gtk.get_minor_version(),
        os.environ.get("XDG_SESSION_TYPE", "?")))
    last = [time.perf_counter()]

    def beat():
        now = time.perf_counter()
        gap = (now - last[0]) * 1000
        if gap > 250:
            dlog("UI STALL        %6.0f ms (main loop was busy)" % gap)
        last[0] = now
        faulthandler.dump_traceback_later(1.5, repeat=False, file=_dbg_file)   # fires only when beat() stops running
        return True
    GLib.timeout_add(100, beat)


GRID_CHUNK = 150          # tiles in the icon view at first; more are added while scrolling          # tile picture in the cover grid (3:4, like a box cover)


def make_thumb(path):
    """Cover-crop a picture to a THUMB_W x THUMB_H tile (None when it cannot be read)."""
    try:
        info = GdkPixbuf.Pixbuf.get_file_info(str(path))
        if not info or not info[0]:
            return None
        sw, sh = info[1], info[2]
        scale = max(THUMB_W / sw, THUMB_H / sh)
        nw, nh = max(THUMB_W, round(sw * scale)), max(THUMB_H, round(sh * scale))
        pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(str(path), nw, nh, False)
        return pb.new_subpixbuf((pb.get_width() - THUMB_W) // 2, (pb.get_height() - THUMB_H) // 2,
                                THUMB_W, THUMB_H).copy()
    except GLib.Error:
        return None


THUMB_DIR = core.DATA_DIR / "thumbs"


def is_blank_cover(path) -> bool:
    """True for an (almost) plain white picture: OAGD serves one for titles whose cover is not published."""
    try:
        pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(str(path), 32, 32, False)
    except GLib.Error:
        return False
    n, rs, px = pb.get_n_channels(), pb.get_rowstride(), pb.get_pixels()
    white = total = 0
    for y in range(pb.get_height()):
        row = y * rs
        for x in range(pb.get_width()):
            o = row + x * n
            total += 1
            if px[o] >= 238 and px[o + 1] >= 238 and px[o + 2] >= 238:
                white += 1
    return total > 0 and white / total >= 0.98


def _thumb_file(path):
    try:
        st = os.stat(path)
        key = hashlib.sha1(f"{path}|{st.st_size}|{st.st_mtime_ns}|{THUMB_W}x{THUMB_H}".encode()).hexdigest()
    except OSError:
        return None
    return THUMB_DIR / (key + ".jpg")


def cached_thumb(path, only_store=False):
    """make_thumb() with a small on-disk cache (keyed by path, size and mtime), so big covers are decoded once.
    Safe to call from a worker thread. With only_store the tile is just written to the cache (returns None):
    used to warm the cache in the background without decoding the cached ones again."""
    f = _thumb_file(path)
    if f is None:
        return None
    if only_store and f.exists():
        return None
    try:
        return GdkPixbuf.Pixbuf.new_from_file(str(f))
    except GLib.Error:
        pass
    pb = make_thumb(path)
    if pb is not None:
        try:
            THUMB_DIR.mkdir(parents=True, exist_ok=True)
            pb.savev(str(f) + ".tmp", "jpeg", ["quality"], ["88"])
            os.replace(str(f) + ".tmp", f)
        except (GLib.Error, OSError):
            pass
    return None if only_store else pb


class Appearance:
    """Light/dark scheme through libadwaita: 'auto' follows the desktop, else forced light or dark."""

    def __init__(self):
        self.mode = "auto"
        self.mgr = Adw.StyleManager.get_default()

    def set_mode(self, mode):
        self.mode = mode if mode in ("auto", "light", "dark") else "auto"
        self.apply()

    def wants_dark(self):
        return bool(self.mgr.get_dark())

    def apply(self):
        self.mgr.set_color_scheme({"light": Adw.ColorScheme.FORCE_LIGHT, "dark": Adw.ColorScheme.FORCE_DARK}
                                  .get(self.mode, Adw.ColorScheme.DEFAULT))


def stars(n):
    n = max(0, min(5, int(n or 0)))
    return "★" * n + "☆" * (5 - n)


def bold(text):
    return "<b>%s</b>" % GLib.markup_escape_text(text)


MARK_NAMES = ("Grafika", "Dźwięk", "Grywalność", "Klimat")      # the sub-scores of a review (same names as the AI import)


CANDY_CSS = b"""
    window.denise-bg toolbarview, window.denise-bg headerbar, window.denise-bg scrolledwindow,
    window.denise-bg gridview, window.denise-bg gridview > child { background: transparent; box-shadow: none; }
    window.denise-night .denise-panel { background: rgba(8,8,24,0.60); }
    window.denise-day .denise-panel { background: rgba(255,255,255,0.55); }
    window.denise-night headerbar button:not(.suggested-action) { background: rgba(255,255,255,0.14); }
    window.denise-night headerbar button:checked { background: rgba(255,255,255,0.32); }
    window.denise-day headerbar button:not(.suggested-action) { background: rgba(255,255,255,0.60); }
    window.denise-day headerbar button:checked { background: rgba(255,255,255,0.95); }
    window.denise-day .denise-panel list.boxed-list, window.denise-night .denise-panel list.boxed-list
        { background: rgba(128,128,160,0.18); }

    /* every window of the program */
    window.denise-candy:not(.denise-bg).denise-day { background: linear-gradient(160deg, #ffe3f1 0%, #e6deff 55%, #d3f8ec 100%); }
    window.denise-candy:not(.denise-bg).denise-night { background: linear-gradient(160deg, #43195f 0%, #2b1b66 60%, #17305f 100%); }
    window.denise-candy:not(.denise-bg) headerbar { background: transparent; box-shadow: none; border-bottom: 2px solid rgba(255,115,179,0.55); }
    window.denise-candy:not(.denise-bg) .dialog-action-area, window.denise-candy:not(.denise-bg) dialog-host { background: transparent; }
    window.denise-candy button { border-radius: 12px; }
    window.denise-candy button.suggested-action { background: linear-gradient(90deg, #ff73b3, #ff9d5c); color: #ffffff; border: none; }
    window.denise-candy button.suggested-action:hover { background: linear-gradient(90deg, #ff8cc2, #ffb07a); }
    window.denise-candy entry, window.denise-candy spinbutton, window.denise-candy combobox button { border-radius: 12px; }
    window.denise-candy entry:focus-within, window.denise-candy spinbutton:focus-within { outline: 2px solid #ff73b3; outline-offset: -2px; }
    window.denise-day:not(.denise-bg) entry, window.denise-day:not(.denise-bg) spinbutton,
    window.denise-day:not(.denise-bg) button:not(.suggested-action):not(.flat) { background: rgba(255,255,255,0.75); }
    window.denise-night:not(.denise-bg) entry, window.denise-night:not(.denise-bg) spinbutton,
    window.denise-night:not(.denise-bg) button:not(.suggested-action):not(.flat) { background: rgba(255,255,255,0.12); }
    window.denise-day:not(.denise-bg) textview, window.denise-day:not(.denise-bg) textview text { background: rgba(255,255,255,0.75); border-radius: 12px; }
    window.denise-night:not(.denise-bg) textview, window.denise-night:not(.denise-bg) textview text { background: rgba(255,255,255,0.12); border-radius: 12px; }
    window.denise-candy check:checked, window.denise-candy radio:checked { background: #ff73b3; border-color: #ff73b3; color: #fff; }
    window.denise-candy switch:checked { background: #ff73b3; }
    window.denise-candy notebook > header { background: transparent; border-color: rgba(255,115,179,0.45); }
    window.denise-candy notebook > header > tabs > tab { border-radius: 12px 12px 0 0; margin: 0 2px; }
    window.denise-candy notebook > header > tabs > tab:checked { background: rgba(255,115,179,0.28); box-shadow: inset 0 -3px #ff73b3; }
    window.denise-candy notebook > stack { background: transparent; }
    window.denise-candy list.boxed-list { background: rgba(255,255,255,0.35); border-radius: 14px; }
    window.denise-night list.boxed-list { background: rgba(255,255,255,0.08); }
    window.denise-candy scale highlight, window.denise-candy progressbar progress { background: linear-gradient(90deg, #ff73b3, #ffd84d); }
    window.denise-candy separator { background: rgba(255,115,179,0.45); }

    /* menus */
    window.denise-candy popover > contents { border-radius: 18px; padding: 2px; }
    window.denise-day popover > contents { background: linear-gradient(160deg, #ffe3f1 0%, #e6deff 55%, #d3f8ec 100%);
        border: 2px solid #ff9fd0; box-shadow: 0 8px 24px rgba(255,105,180,0.35); }
    window.denise-night popover > contents { background: linear-gradient(160deg, #43195f 0%, #2b1b66 60%, #17305f 100%);
        border: 2px solid #ff7ac0; box-shadow: 0 8px 24px rgba(255,105,180,0.30); }
    window.denise-candy popover button.flat { border-radius: 12px; margin: 1px 0; border-left: 6px solid #ff73b3; }
    window.denise-candy popover button.flat:nth-child(5n+2) { border-left-color: #ff9d5c; }
    window.denise-candy popover button.flat:nth-child(5n+3) { border-left-color: #ffd84d; }
    window.denise-candy popover button.flat:nth-child(5n+4) { border-left-color: #5fd89a; }
    window.denise-candy popover button.flat:nth-child(5n+5) { border-left-color: #6bb8ff; }
    window.denise-day popover button.flat { background: rgba(255,255,255,0.65); }
    window.denise-night popover button.flat { background: rgba(255,255,255,0.10); }
    window.denise-day popover button.flat:hover { background: #ffffff; }
    window.denise-night popover button.flat:hover { background: rgba(255,255,255,0.24); }
    window.denise-candy popover separator { background: rgba(255,115,179,0.55); min-height: 2px; margin: 4px 10px; border-radius: 1px; }
    window.denise-candy popover label.caption-heading { color: #ff5fae; }
"""
_candy_provider = None


def style_window(win, on, dark, background=False):
    """Give a window the candy look (CSS classes); background=True is the main window, which draws its own backdrop."""
    global _candy_provider
    if _candy_provider is None:
        _candy_provider = Gtk.CssProvider()
        _candy_provider.load_from_data(CANDY_CSS)
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), _candy_provider,
                                                  Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
    for cls, want in (("denise-candy", on), ("denise-bg", on and background),
                      ("denise-night", on and dark), ("denise-day", on and not dark)):
        (win.add_css_class if want else win.remove_css_class)(cls)


def candy_hook(win):
    """Called for every window the program shows (dialogs, wizard, about ...): they get the candy look too."""
    app = Gio.Application.get_default()
    main = getattr(app, "main_window", None) if app else None
    if main is None or win is main or not hasattr(main, "settings"):
        return
    if getattr(win, "_candy_done", False):
        return
    win._candy_done = True
    mgr = Adw.StyleManager.get_default()

    def restyle(*_a):
        style_window(win, bool(main.settings.get("retro_background", True)), bool(mgr.get_dark()))
    restyle()
    hid = mgr.connect("notify::dark", restyle)
    win.connect("destroy", lambda *a: mgr.disconnect(hid))


gtk4_compat.present_hooks.append(candy_hook)


class RetroBackground(Gtk.Widget):
    """Original candy-coloured retro backdrop drawn with Gtk.Snapshot: pastel gradient with sweets-coloured "copper"
    bars, or a pattern of floppy disks. Light and dark variants follow the colour scheme."""
    CANDY = ((1.0, 0.45, 0.70), (1.0, 0.62, 0.35), (1.0, 0.86, 0.30), (0.45, 0.88, 0.62), (0.40, 0.75, 1.0),
             (0.70, 0.55, 1.0))

    def __init__(self, style="copper", dark=False):
        super().__init__()
        self.style, self.dark = style, dark
        self.set_hexpand(True)
        self.set_vexpand(True)

    def configure(self, style, dark):
        if (style, dark) != (self.style, self.dark):
            self.style, self.dark = style, dark
            self.queue_draw()

    def do_snapshot(self, snap):
        w, h = self.get_width(), self.get_height()
        if w <= 0 or h <= 0:
            return
        dark = self.dark
        snap.push_clip(Graphene.Rect().init(0, 0, w, h))

        def rgba(r, g, b, a=1.0):
            c = Gdk.RGBA()
            c.red, c.green, c.blue, c.alpha = r, g, b, a
            return c

        def rect(x, y, ww, hh):
            return Graphene.Rect().init(x, y, ww, hh)

        def stop(o, c):
            st = Gsk.ColorStop()
            st.offset, st.color = o, c
            return st

        def mix(c, k):                                      # towards white (k>0) or dark (k<0)
            return tuple(min(1.0, max(0.0, v + (1 - v) * k if k > 0 else v * (1 + k))) for v in c)

        def rounded(c, x, y, ww, hh, r):
            rr = Gsk.RoundedRect()
            rr.init_from_rect(rect(x, y, ww, hh), r)
            snap.push_rounded_clip(rr)
            snap.append_color(c, rect(x, y, ww, hh))
            snap.pop()
        if dark:
            stops = [stop(0.0, rgba(0.16, 0.08, 0.30)), stop(0.55, rgba(0.30, 0.10, 0.38)), stop(1.0, rgba(0.10, 0.12, 0.34))]
        else:
            stops = [stop(0.0, rgba(1.0, 0.84, 0.93)), stop(0.5, rgba(0.88, 0.85, 1.0)), stop(1.0, rgba(0.80, 0.96, 0.90))]
        snap.append_linear_gradient(rect(0, 0, w, h), Graphene.Point().init(0, 0), Graphene.Point().init(0, h), stops)
        if self.style == "floppy":
            size = max(46.0, min(w, h) * 0.075)
            step = size * 1.9
            row = 0
            y = -size * 0.3
            while y < h:
                x = -size * 0.5 + (step / 2 if row % 2 else 0)
                col = row
                while x < w:
                    base = self.CANDY[(col * 2 + row) % len(self.CANDY)]
                    body = rgba(*(mix(base, -0.35) if dark else base), 0.55)
                    rounded(body, x, y, size, size, size * 0.08)
                    rounded(rgba(1, 1, 1, 0.65), x + size * 0.22, y, size * 0.56, size * 0.34, size * 0.04)      # shutter
                    rounded(rgba(0.35, 0.35, 0.45, 0.55), x + size * 0.58, y + size * 0.05, size * 0.1, size * 0.24, 1)
                    rounded(rgba(1, 1, 1, 0.80), x + size * 0.14, y + size * 0.50, size * 0.72, size * 0.40, size * 0.04)  # label
                    rounded(rgba(*base, 0.85), x + size * 0.22, y + size * 0.60, size * 0.4, size * 0.07, 1)
                    rounded(rgba(*base, 0.85), x + size * 0.22, y + size * 0.74, size * 0.28, size * 0.07, 1)
                    x += step
                    col += 1
                y += step * 0.62
                row += 1
        else:
            bar_h = max(8.0, h * 0.032)
            y0 = h * 0.58
            for i, base in enumerate(self.CANDY):
                y = y0 + i * bar_h * 1.15
                hi = rgba(*base, 0.95)
                lo = rgba(*mix(base, -0.25 if dark else 0.45), 0.95)
                snap.append_linear_gradient(rect(0, y, w, bar_h), Graphene.Point().init(0, y),
                                            Graphene.Point().init(0, y + bar_h), [stop(0.0, lo), stop(0.5, hi), stop(1.0, lo)])
            # sprinkles: little rounded candies scattered over the upper area
            seed = 7
            for i in range(46):
                seed = (seed * 1103515245 + 12345) & 0x7FFFFFFF
                px = (seed % 1000) / 1000.0 * w
                seed = (seed * 1103515245 + 12345) & 0x7FFFFFFF
                py = (seed % 1000) / 1000.0 * h * 0.55
                base = self.CANDY[i % len(self.CANDY)]
                rounded(rgba(*base, 0.75), px, py, 14, 5, 2.5)
        # scrim keeps covers and text readable: white veil in light mode, dark veil in dark mode
        snap.append_color(rgba(0, 0, 0, 0.42) if dark else rgba(1, 1, 1, 0.38), rect(0, 0, w, h))
        snap.pop()


class Tile(GObject.Object):
    """One game in the cover grid. Indexable like the old list-store row:
    0 id, 1 title, 2 genre, 3 year, 4 stars, 5 plays, 6 fav, 7 tile picture (pixbuf), 8 path, 9 label, 10 folder."""
    __gtype_name__ = "DeniseTile"

    def __init__(self, row):
        super().__init__()
        self.v = list(row)
        self.cb = None                                   # called when the picture changes (set while the tile is on screen)

    def __getitem__(self, i):
        return self.v[i]

    def __setitem__(self, i, val):
        self.v[i] = val
        if i == 7 and self.cb:
            self.cb()


class TileStore:
    """Thin wrapper over a Gio.ListStore of Tile objects with the few list-store calls the program uses."""

    def __init__(self):
        self.model = Gio.ListStore.new(Tile)

    def __len__(self):
        return self.model.get_n_items()

    def __getitem__(self, i):
        return self.model.get_item(i)

    def clear(self):
        self.model.remove_all()

    def extend(self, rows):
        self.model.splice(len(self), 0, [Tile(r) for r in rows])


class MainWindow(Adw.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title="Denise Station")
        core.migrate_old_data()
        self.settings = core.load_settings()
        app.main_window = self                          # windows opened later get the candy look (candy_hook)

        def scan_windows():                              # safety net: any window, however it was shown, gets the look
            for w in Gtk.Window.list_toplevels():
                if w is not self and w.get_visible() and not getattr(w, "_candy_done", False):
                    try:
                        candy_hook(w)
                    except Exception as e:               # noqa: BLE001
                        dlog("candy_hook failed: %r" % (e,))
            return True
        GLib.timeout_add(250, scan_windows)
        i18n.set_language(self.settings["language"])
        self.appearance = Appearance()
        self.appearance.set_mode(self.settings.get("appearance", "auto"))
        self.set_default_size(1380, 780)
        self.maximize()                                   # starts maximized (the size above is used after un-maximizing)
        core.DATA_DIR.mkdir(parents=True, exist_ok=True)
        core.SCREENS_DIR.mkdir(parents=True, exist_ok=True)
        try:
            core.GAMES_DIR.mkdir(parents=True, exist_ok=True)
        except OSError:
            pass
        self.lib = core.Library(core.DB_PATH)
        if self.settings.get("legacy_folders"):        # the game folder is now fixed: carry the library over
            core.migrate_library_paths(self.lib.db, self.settings["legacy_folders"])
            core.save_settings(self.settings)
        self.view = ("genre", "Games")
        self.current_id = None
        self._refreshing = False
        self._scraping = False
        self.cancel = threading.Event()

        self._fullscreen = False
        self._build_header()
        self._build_body()
        keys = Gtk.EventControllerKey()
        keys.set_propagation_phase(Gtk.PropagationPhase.CAPTURE)
        keys.connect("key-pressed", self.on_key)
        self.add_controller(keys)
        self.refresh_sidebar()
        self.refresh_list()
        self.refresh_state_list(self.lib.get(self.current_id) if self.current_id else None)
        self.b_stop.set_visible(False)
        GLib.idle_add(self.check_updates)
        if not self.settings.get("setup_done"):
            if setup_wizard.is_done(self.settings):      # an older, working install: nothing to set up
                self.settings["setup_done"] = True
                core.save_settings(self.settings)
            else:
                GLib.idle_add(self.run_wizard)
        GLib.idle_add(self.purge_blank_covers)
        GLib.timeout_add(4000, self.check_amiberry_update)

    # ------------------------------------------------------------------ UI
    def _build_header(self):
        hb = Adw.HeaderBar()
        hb.set_title_widget(Gtk.Box())                  # empty centre, so the tabs may use the whole left side

        # category tabs: a row of linked toggle buttons on the left of the header bar, scrolls sideways when narrow
        self.tab_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        self.tab_box.add_css_class("linked")
        self.tab_sw = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.EXTERNAL,
                                         vscrollbar_policy=Gtk.PolicyType.NEVER, propagate_natural_width=True)
        self.tab_sw.set_min_content_width(200)
        self.tab_sw.set_child(self.tab_box)

        self.search = Gtk.SearchEntry(placeholder_text=_("Search title, developer, publisher…"))
        self.search.set_width_chars(34)
        self.search.connect("search-changed", lambda *a: self.refresh_list())
        self.search_btn = Gtk.ToggleButton(icon_name="edit-find-symbolic")
        self.search_btn.set_tooltip_text(_("Search") + " (Ctrl+F)")
        self.search_btn.connect("toggled", lambda b: self.show_search(b.get_active()))
        hb.pack_start(self.search_btn)
        hb.pack_start(self.search)
        hb.pack_start(self.tab_sw)                    # tabs hug the left side
        self.search.set_visible(False)                # hidden until the magnifier or Ctrl+F

        self.hb = hb

        self.dl_btn = dl_btn = Gtk.Button(icon_name="folder-download-symbolic")
        dl_btn.set_tooltip_text(_("Download games") + " – " + _("WHDLoad download…"))
        dl_btn.connect("clicked", lambda *a: whdload_dialog.open_dialog(self))

        self.scrape_btn = Gtk.Button(icon_name="dialog-information-symbolic")
        self.scrape_btn.set_tooltip_text(_("Scrape") + " – " + _("Scrape all missing info"))
        self.scrape_btn.connect("clicked", lambda *a: self.scrape_missing())

        self.menu_btn = menu_btn = Gtk.MenuButton(icon_name="open-menu-symbolic")
        # groups: settings | Amiberry tools | Logs | Keyboard shortcuts, About
        menu_button_model(menu_btn, [
            (_("Settings…"), self.open_settings),
            (_("Amiberry configuration…"), self.edit_amiberry_conf),
            None,
            (_("Open Amiberry"), self.open_amiberry),
            (_("Amiberry versions…"), self.manage_versions),
            (_("Setup wizard…"), self.run_wizard),
            None,
            (_("Logs"), [(_("Open last launch log"), self.open_log),
                         (_("Open last scraping log"), self.open_scrape_log)]),
            None,
            (_("Keyboard shortcuts…"), self.show_shortcuts),
            (_("About"), self.show_about)])
        self.fw_btn = Gtk.ToggleButton(icon_name="video-display-symbolic")
        self.fw_btn.set_active(bool(self.settings.get("amiberry_fullwindow")))
        self.fw_btn.set_tooltip_text(_("Amiberry: start in full window mode"))
        self.fw_btn.connect("toggled", self.on_fullwindow_toggled)
        self.fs_btn = Gtk.Button(icon_name="view-fullscreen-symbolic")
        self.fs_btn.set_tooltip_text(_("Full screen") + " (F11)")
        self.fs_btn.connect("clicked", lambda *a: self.toggle_fullscreen())
        self.connect("notify::fullscreened", self.on_window_state)

        rnd = Gtk.Button(icon_name="media-playlist-shuffle-symbolic")
        rnd.set_tooltip_text(_("Pick a random game (Ctrl+R)"))
        rnd.connect("clicked", lambda *a: self.pick_random())

        scan = Gtk.Button(icon_name="view-refresh-symbolic")
        scan.set_tooltip_text(_("Rescan game folders (F5)"))
        scan.connect("clicked", lambda *a: self.start_scan())
        self.sh_btn = Gtk.Button(icon_name="applications-graphics-symbolic")
        self.sh_btn.connect("clicked", lambda *a: self.cycle_shader())
        self._shader_tip()

        # right side, left to right: Amiberry full window, shader, random | rescan, scrape, download | full screen, menu
        def sep():
            return Gtk.Separator(orientation=Gtk.Orientation.VERTICAL, margin_top=8, margin_bottom=8)
        for w in reversed((self.fw_btn, self.sh_btn, rnd, sep(), scan, self.scrape_btn, dl_btn, sep(),
                           self.fs_btn, menu_btn)):
            hb.pack_end(w)

    def _build_body(self):
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        tv = Adw.ToolbarView()
        tv.add_top_bar(self.hb)
        tv.set_content(outer)
        self.bg = RetroBackground()                  # the backdrop covers the whole window; everything else is drawn over it
        self.root_stack = Gtk.Overlay()
        self.root_stack.set_child(self.bg)
        self.root_stack.add_overlay(tv)
        self.set_content(self.root_stack)

        inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)     # games on the left, a compact fixed-width panel on the right
        inner.set_vexpand(True)
        outer.append(inner)

        # cover grid: a virtualised GridView, so only the tiles on screen exist as widgets
        self.store = TileStore()
        self.sel = Gtk.SingleSelection(model=self.store.model)
        self.sel.set_autoselect(False)
        self.sel.set_can_unselect(True)
        factory = Gtk.SignalListItemFactory()
        factory.connect("setup", self._tile_setup)
        factory.connect("bind", self._tile_bind)
        factory.connect("unbind", self._tile_unbind)
        self.grid = Gtk.GridView(model=self.sel, factory=factory, single_click_activate=False,
                                 min_columns=2, max_columns=30, **mg(6))
        self.sel.connect("notify::selected", self.on_grid_selected)
        self.grid.connect("activate", lambda *a: self.play_current())
        self.sw_grid = Gtk.ScrolledWindow(hexpand=True, vexpand=True)
        self.sw_grid.set_child(self.grid)

        # category tabs live in the header bar; favourites come first inside each tab
        self._tab_vals = []
        inner.append(self.sw_grid)
        self._tsig = None
        self._rows = []
        self._tcache = collections.OrderedDict()     # game id -> tile (memory)
        self._tpending = set()
        self._tmissing = set()
        self._bound = {}                             # game id -> Tile that is on screen right now
        self._tpool = ThreadPoolExecutor(max_workers=min(6, max(3, os.cpu_count() or 4)))   # decoding releases the GIL
        self._warm_gen = 0
        self._placeholders = {}
        self._detail_folder = ""

        inner.append(Gtk.Separator(orientation=Gtk.Orientation.VERTICAL))
        panel = self._build_detail()
        panel.add_css_class("denise-panel")
        inner.append(panel)
        self.inner = inner
        self.apply_background()
        self.appearance.mgr.connect("notify::dark", lambda *a: self.apply_background())

        outer.append(Gtk.Separator())
        bar = Gtk.Box(spacing=6, **mg(4))
        self.status = Gtk.Label(xalign=0, ellipsize=Pango.EllipsizeMode.END, hexpand=True)
        bar.append(self.status)
        self.b_stop = Gtk.Button(label=_("Stop"))
        self.b_stop.connect("clicked", lambda *a: self.cancel.set())
        bar.append(self.b_stop)
        outer.append(bar)

    def apply_background(self):
        on = bool(self.settings.get("retro_background", True))
        dark = self.appearance.wants_dark()
        self.bg.set_visible(on)
        self.bg.configure(self.settings.get("retro_style", "copper"), dark)
        style_window(self, on, dark, background=True)

    # ---- grid tiles
    def _tile_setup(self, _f, li):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4, **mg(4))
        box.set_size_request(THUMB_W + 14, -1)
        pic = Gtk.Picture(content_fit=Gtk.ContentFit.FILL, can_shrink=False, halign=Gtk.Align.CENTER, valign=Gtk.Align.START)
        pic.set_size_request(THUMB_W, THUMB_H)
        pic.add_css_class("denise-cover")
        lab = Gtk.Label(wrap=True, wrap_mode=Pango.WrapMode.WORD_CHAR, justify=Gtk.Justification.CENTER,
                        max_width_chars=14, lines=3, ellipsize=Pango.EllipsizeMode.END)
        lab.add_css_class("caption")
        box.append(pic)
        box.append(lab)
        click = Gtk.GestureClick(button=3)
        click.connect("pressed", self._tile_right_click, li)
        box.add_controller(click)
        li.set_child(box)

    def _tile_bind(self, _f, li):
        item, box = li.get_item(), li.get_child()
        pic, lab = box.get_first_child(), box.get_last_child()
        lab.set_text(item[9])

        def refresh():
            pb = item[7]
            pic.set_paintable(Gdk.Texture.new_for_pixbuf(pb) if pb is not None else None)
        item.cb = refresh
        refresh()
        self._bound[item[0]] = item
        if item[7] is self.placeholder_thumb(item[10]):
            self.request_thumb(item)

    def _tile_unbind(self, _f, li):
        item = li.get_item()
        if item is not None:
            item.cb = None
            if self._bound.get(item[0]) is item:
                del self._bound[item[0]]

    def _tile_right_click(self, gesture, n, x, y, li):
        pos = li.get_position()
        if pos == Gtk.INVALID_LIST_POSITION:
            return
        self.sel.set_selected(pos)
        self.show_context_menu(li.get_child(), x, y)

    def _build_detail(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, **mg(8))
        box.set_size_request(DETAIL_W, -1)
        self.shot = Gtk.Picture(can_shrink=False, halign=Gtk.Align.CENTER)       # click on the cover opens a large preview
        click = Gtk.GestureClick()
        click.connect("pressed", lambda *a: self.preview_cover())
        self.shot.add_controller(click)
        # the picture area is a stack: cover | "looking for a video" | the video itself
        self.media = Gtk.Stack(vhomogeneous=False, hhomogeneous=False, halign=Gtk.Align.CENTER)
        self.media.add_named(self.shot, "cover")
        busy = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, halign=Gtk.Align.CENTER, valign=Gtk.Align.CENTER)
        busy.set_size_request(DETAIL_W - 16, (DETAIL_W - 16) * 3 // 4)
        self.pv_spin = Gtk.Spinner(spinning=False)
        self.pv_spin.set_size_request(32, 32)
        busy.append(self.pv_spin)
        self.pv_text = Gtk.Label(label=_("Looking for a video…"))
        busy.append(self.pv_text)
        self.media.add_named(busy, "busy")
        # a plain picture showing the media stream: no player controls over the video; click = pause / play.
        # Longplays are usually a 4:3 Amiga picture inside a 16:9 frame, so the box is 4:3 and the picture fills it.
        self.vid = Gtk.Picture(content_fit=Gtk.ContentFit.COVER, can_shrink=True, halign=Gtk.Align.CENTER)
        self.vid.set_size_request(DETAIL_W - 16, (DETAIL_W - 16) * 3 // 4)       # 4:3 like the Amiga picture; COVER trims the black side bars
        self._stream = None
        vclick = Gtk.GestureClick()

        def toggle_play(*_a):
            st = self._stream
            if st is not None:
                st.pause() if st.get_playing() else st.play()
        vclick.connect("pressed", toggle_play)
        self.vid.add_controller(vclick)
        # buttons that appear when the pointer is over the video: another video / close
        vover = Gtk.Overlay()
        vover.set_child(self.vid)
        self.pv_tools = Gtk.Revealer(transition_type=Gtk.RevealerTransitionType.CROSSFADE, reveal_child=False,
                                     halign=Gtk.Align.END, valign=Gtk.Align.START)
        tools = Gtk.Box(spacing=6, **mg(6))
        for icon, tip, fn in (("media-skip-forward-symbolic", _("Find another video"), lambda *a: self.find_other_video()),
                              ("window-close-symbolic", _("Close the video"), lambda *a: self.stop_preview())):
            b_ = Gtk.Button.new_from_icon_name(icon)
            b_.add_css_class("osd")
            b_.add_css_class("circular")
            b_.set_tooltip_text(tip)
            b_.connect("clicked", fn)
            tools.append(b_)
        self.pv_tools.set_child(tools)
        vover.add_overlay(self.pv_tools)
        hover = Gtk.EventControllerMotion()
        hover.connect("enter", lambda *a: self.pv_tools.set_reveal_child(True))
        hover.connect("leave", lambda *a: self.pv_tools.set_reveal_child(False))
        vover.add_controller(hover)
        self.media.add_named(vover, "video")
        box.append(self.media)
        self.pv_title = Gtk.Label(xalign=0.5, ellipsize=Pango.EllipsizeMode.END, visible=False)
        self.pv_title.add_css_class("caption")
        self.pv_title.add_css_class("dim-label")
        box.append(self.pv_title)
        self.b_pv = Gtk.Button(label="🎬  " + _("Preview video"))
        self.b_pv.add_css_class("flat")
        self.b_pv.connect("clicked", lambda *a: self.toggle_preview())
        box.append(self.b_pv)
        self._pv_gen = 0

        self._cover_pic = None

        self.d_title = Gtk.Label(xalign=0, wrap=True, selectable=True)
        box.append(self.d_title)
        # rating and description sit right under the picture and title
        self.d_stars = Gtk.Label(xalign=0, use_markup=True)
        box.append(self.d_stars)
        self.d_marks = Gtk.Label(xalign=0, wrap=True, max_width_chars=1)
        self.d_marks.add_css_class("dim-label")
        box.append(self.d_marks)
        # The whole detail panel scrolls, so the description is shown in full (no line limit).
        self.d_notes = Gtk.Label(xalign=0, yalign=0, wrap=True, selectable=True, max_width_chars=1)
        box.append(self.d_notes)

        grid = Gtk.Grid(column_spacing=12, row_spacing=2, halign=Gtk.Align.START)
        self.d_vals = {}
        for i, (key, label) in enumerate((("genre", _("Genre")), ("year", _("Year")),
                                          ("developer", _("Developer")),
                                          ("publisher", _("Publisher")),
                                          ("plays", _("Played")), ("last", _("Last played")),
                                          ("scraped", _("Info source")), ("amiberry", _("Amiberry")))):
            k = Gtk.Label(label=label, xalign=0, yalign=0, halign=Gtk.Align.START)
            k.add_css_class("dim-label")
            v = Gtk.Label(xalign=0, wrap=True, selectable=True, halign=Gtk.Align.START)
            grid.attach(k, 0, i, 1, 1)
            grid.attach(v, 1, i, 1, 1)
            self.d_vals[key] = v
        box.append(grid)

        # The file path gets the full width of the panel (below the table) and wraps instead of being cut.
        k = Gtk.Label(label=_("File"), xalign=0)
        k.add_css_class("dim-label")
        box.append(k)
        v = Gtk.Label(xalign=0, wrap=True, wrap_mode=Pango.WrapMode.CHAR, selectable=True, max_width_chars=1)
        self.d_vals["file"] = v
        box.append(v)

        bar = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, **mg(8))   # always visible, never scrolled away
        # Play over the whole width; the game's savestates below it (date and time only, double-click starts from it)
        self.b_play = Gtk.Button(label="▶  " + _("Play"))
        self.b_play.add_css_class("suggested-action")
        self.b_play.connect("clicked", lambda *a: self.play_current())
        bar.append(self.b_play)
        self.st_label = Gtk.Label(label=_("Savestates"), xalign=0)
        self.st_label.add_css_class("dim-label")
        self.st_list = Gtk.ListBox(selection_mode=Gtk.SelectionMode.SINGLE)
        self.st_list.add_css_class("boxed-list")
        self.st_list.set_tooltip_text(_("Double-click: play from this savestate") + "\n" + _("Right click: Rename…, Delete"))
        self.st_list.connect("row-activated", lambda lb, row: self.play_current(row.state_path))
        rc = Gtk.GestureClick(button=3)
        rc.connect("pressed", self.on_state_click)
        self.st_list.add_controller(rc)
        self.st_sw = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER)
        self.st_sw.set_min_content_height(110)
        self.st_sw.set_max_content_height(220)
        self.st_sw.set_propagate_natural_height(True)
        self.st_sw.set_child(self.st_list)
        bar.append(self.st_label)
        bar.append(self.st_sw)

        sw = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER, vexpand=True)
        sw.set_child(box)
        panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        panel.set_size_request(DETAIL_W + 20, -1)
        panel.append(self.build_banner())
        panel.append(sw)
        panel.append(bar)
        return panel

    def build_banner(self):
        """Banner above the cover: icon, name and version of the program."""
        banner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10, margin_start=12, margin_end=12,
                         margin_top=8, margin_bottom=8)
        icon_file = Path(__file__).resolve().parent / "assets" / "denise-station.png"
        if icon_file.exists():
            img = Gtk.Image.new_from_file(str(icon_file))
        else:
            img = Gtk.Image.new_from_icon_name("applications-games")
        img.set_pixel_size(40)
        banner.append(img)
        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
        name = Gtk.Label(xalign=0)
        name.set_markup("<span size='x-large' weight='bold'>Denise Station</span>")
        ver = Gtk.Label(xalign=0, label="v%s" % core.VERSION)
        ver.add_css_class("dim-label")
        text.append(name)
        text.append(ver)
        banner.append(text)
        frame = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        frame.append(banner)
        frame.append(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL))
        return frame

    # ------------------------------------------------------------ refresh
    def say(self, text):
        self.status.set_text(text)
        return False

    TAB_ORDER = (("games", ""), ("beta-game", ""), ("beta-games", ""), ("demos", ""), ("demo", ""),
                 ("beta-demo", ""), ("beta-demos", ""), ("magazines", ""))

    def refresh_sidebar(self):
        """Rebuild the tab bar (there is no sidebar any more): Games, Beta-Game, Demos, Beta-Demo, Magazines,
        then any other genre; Recently played comes first."""
        self._refreshing = True
        counts = dict(self.lib.genre_counts())
        fixed = {k: (i, lab) for i, (k, lab) in enumerate(self.TAB_ORDER)}
        entries, used = [("recent", None, _("Recently played"))], set()          # first tab
        for key, (rank, lab) in sorted(fixed.items(), key=lambda kv: kv[1][0]):
            for g, n in counts.items():
                if g and g.strip().lower() == key and g not in used:
                    used.add(g)
                    entries.append(("genre", g, "%s (%d)" % (g, n)))       # the original folder name
        for g in sorted((g for g in counts if g and g not in used), key=str.lower):
            entries.append(("genre", g, "%s (%d)" % (g, counts[g])))
        if counts.get(""):
            entries.append(("genre", "", "%s (%d)" % (_("Unsorted"), counts[""])))
        self._tab_vals = [(k, v) for k, v, _l in entries]
        for old in children_of(self.tab_box):
            self.tab_box.remove(old)
        self._tab_btns = []
        for i, (k, v, label) in enumerate(entries):
            tb = Gtk.ToggleButton(label=label)
            tb.connect("toggled", self.on_tab_toggled, i)
            self.tab_box.append(tb)
            self._tab_btns.append(tb)
        full = {(k, v) for k, v, lab in entries if k == "genre" and not lab.endswith("(0)")}
        if (not getattr(self, "_tab_chosen", False) and full and self.view not in full) \
                or self.view not in self._tab_vals or (self.view[0] == "genre" and self.view not in full and full):
            # an unknown or empty tab (e.g. an empty category while the library was still empty): the first tab with games
            self.view = next(((k, v) for k, v, lab in entries if (k, v) in full), self._tab_vals[0])
        self._tab_btns[self._tab_vals.index(self.view)].set_active(True)
        self._refreshing = False
        GLib.idle_add(self.scroll_tab_into_view)

    def scroll_tab_into_view(self):
        """Keep the active tab visible in the (horizontally scrolling) strip."""
        for tb in getattr(self, "_tab_btns", []):
            if tb.get_active():
                ok, pt = tb.compute_point(self.tab_box, Graphene.Point())
                adj = self.tab_sw.get_hadjustment()
                w = tb.get_width()
                if ok and (pt.x < adj.get_value() or pt.x + w > adj.get_value() + adj.get_page_size()):
                    adj.set_value(max(0, pt.x - 20))
        return False

    def on_tab_toggled(self, btn, i):
        if self._refreshing or i >= len(self._tab_vals):
            return
        if not btn.get_active():                              # a tab stays selected when clicked again
            if self._tab_vals[i] == self.view:
                self._refreshing = True
                btn.set_active(True)
                self._refreshing = False
            return
        self._refreshing = True                               # radio behaviour: release the others
        for j, other in enumerate(self._tab_btns):
            other.set_active(j == i)
        self._refreshing = False
        self.view = self._tab_vals[i]
        self._tab_chosen = True                               # from now on the tab you picked is kept
        self.refresh_list()

    @dtimed("refresh_list")
    def refresh_list(self):
        kind, value = self.view
        qkind = "favorites" if kind == "favorite" else kind
        rows = self.lib.query(self.search.get_text().strip(), qkind, value)
        keep = self.current_id
        self._refreshing = True
        self.store.clear()
        try:
            sig = core.SCREENS_DIR.stat().st_mtime_ns    # covers added or changed since the last fill?
        except OSError:
            sig = 0
        if sig != self._tsig:
            self._tcache.clear()
            self._tmissing.clear()
            self._tsig = sig
        self._rows = rows
        idx = next((i for i, r in enumerate(rows) if r["id"] == keep), 0 if rows else None)
        self.append_rows(0, len(rows))                   # the grid is virtualised: all rows are cheap
        if idx is not None:
            self.select_row(idx)
        self._refreshing = False
        self.show_detail(rows[idx]["id"] if idx is not None else None)
        self.warm_thumbs(rows)
        if not self._scraping:
            self.say(_("Games: {n}").format(n=len(rows)))

    @dtimed("show_detail")
    def show_detail(self, gid):
        changed = gid != getattr(self, "current_id", None)
        if changed:
            self.stop_preview()
        self.current_id = gid
        if changed and gid and self.settings.get("preview_autoplay", True):
            GLib.timeout_add(700, self._auto_preview, gid)      # not while scrolling past games
        g = self.lib.get(gid) if gid else None
        self.b_play.set_sensitive(g is not None)
        if g is None:
            self.d_title.set_markup("<big>%s</big>" % GLib.markup_escape_text(_("No game selected")))
            for v in self.d_vals.values():
                v.set_text("")
            self.d_notes.set_text("")
            self.d_notes.set_visible(False)
            self.refresh_state_list(None)
            self.d_stars.set_text("")
            self.d_marks.set_text("")
            self.d_stars.hide()
            self.d_marks.hide()
            self.shot.set_paintable(None)
            self._cover_pic = None
            return
        self.d_title.set_markup("<span size='x-large' weight='bold'>%s</span>"
                                % GLib.markup_escape_text(g["title"]))
        v = self.d_vals
        v["genre"].set_text(g["genre"] or _("Unsorted"))
        v["year"].set_text(g["year"])
        v["developer"].set_text(g["developer"])
        v["publisher"].set_text(g["publisher"])
        v["plays"].set_text(f"{g['plays']}×")
        tag = core.game_amiberry(g)
        v["amiberry"].set_text(tag if tag else _("Default version"))
        v["last"].set_text(time.strftime("%Y-%m-%d %H:%M", time.localtime(g["last_played"]))
                           if g["last_played"] else _("never"))
        if g["scraped"] > 0:
            src = {"oagd": "OAGD", "libretro": _("Libretro (cover only)")}.get(g["source"], "")
            when = time.strftime("%Y-%m-%d", time.localtime(g["scraped"]))
            v["scraped"].set_text(f"{src}, {when}" if src else when)
        elif g["scraped"] < 0:
            v["scraped"].set_text(_("no match found"))
        else:
            v["scraped"].set_text(_("not yet"))
        v["file"].set_text(g["path"])
        v["file"].set_tooltip_text(g["path"])
        self.d_notes.set_text(g["notes"])
        self.d_notes.set_visible(bool(g["notes"]))
        self.refresh_state_list(g)
        self.show_score(g)
        self._detail_folder = g["folder"]
        self._cover_pic = core.screenshot_for(g)        # None = the placeholder of the category
        self.show_cover()

    def refresh_state_list(self, g):
        """The compact savestate list below the Play button (hidden when the game has none)."""
        while (row := self.st_list.get_first_child()) is not None:
            self.st_list.remove(row)
        states = core.find_savestates(self.settings, g) if g else []
        for st in states:
            row = Gtk.ListBoxRow()
            row.state_path = st["path"]
            row.set_child(Gtk.Label(label=time.strftime("%Y-%m-%d %H:%M", time.localtime(st["mtime"])), xalign=0,
                                    margin_top=6, margin_bottom=6, margin_start=10, margin_end=10))
            self.st_list.append(row)
        self.st_label.set_visible(bool(states))                   # nothing to show without savestates
        self.st_sw.set_visible(bool(states))

    def show_score(self, g):
        """Magazine-style score (0-10) with its parts; the plain star rating when there is no score."""
        if g["score"]:
            sc = ("%.1f" % g["score"]).rstrip("0").rstrip(".")
            self.d_stars.set_markup("<span size='xx-large' weight='bold' foreground='#e0a800'>%s</span>"
                                    "<span size='large' foreground='#e0a800'>/10</span>" % sc)
            try:
                parts = json.loads(g["marks"]) if g["marks"] else {}
            except ValueError:
                parts = {}
            self.d_marks.set_text("   ".join("%s %s" % (n, ("%.1f" % x).rstrip("0").rstrip(".")) for n, x in parts.items()))
            self.d_marks.set_visible(bool(parts))
        else:
            self.d_stars.set_markup("<span size='large' foreground='#e0a800'>%s</span>" % stars(g["rating"])
                                    if g["rating"] else "")
            self.d_marks.set_text("")
            self.d_marks.set_visible(False)           # no empty gap between the stars and the text
        self.d_stars.set_visible(bool(g["score"] or g["rating"]))

    COVER_W, COVER_MAX_H = DETAIL_W - 16, 400             # the cover fills the panel width (panel 380 - margins)

    def _cover_path(self):
        pic = self._cover_pic
        if pic:
            return str(pic)
        if core.PLACEHOLDER_COVER.exists():
            return str(core.placeholder_for(self._detail_folder))
        return None

    def show_cover(self):
        path = self._cover_path()
        try:
            if path:
                pb = GdkPixbuf.Pixbuf.new_from_file(path)
                w, h = pb.get_width(), pb.get_height()
                k = min(self.COVER_W / w, self.COVER_MAX_H / h)
                if abs(k - 1) > 0.001:
                    pb = pb.scale_simple(max(1, int(w * k)), max(1, int(h * k)), GdkPixbuf.InterpType.BILINEAR)
                self.shot.set_paintable(Gdk.Texture.new_for_pixbuf(pb))
                self.shot.set_tooltip_text(_("Click to enlarge"))
            else:
                self.shot.set_paintable(None)
        except GLib.Error:
            self.shot.set_paintable(None)

    # ---- video preview (yt-dlp)
    def stop_preview(self):
        self._pv_gen += 1
        self.pv_spin.stop()
        if self._stream is not None:
            try:
                self._stream.pause()
            except Exception:                                    # noqa: BLE001
                pass
        self._stream = None
        self.vid.set_paintable(None)
        self.pv_title.set_visible(False)
        self.media.set_visible_child_name("cover")
        self.update_pv_button()

    def update_pv_button(self):
        """The start button only exists while the cover is shown and previews do not start by themselves."""
        self.b_pv.set_visible(self.media.get_visible_child_name() == "cover"
                              and not self.settings.get("preview_autoplay", True))

    def _auto_preview(self, gid):
        if gid == self.current_id and self.media.get_visible_child_name() == "cover" \
                and self.settings.get("preview_autoplay", True):
            self.toggle_preview(auto=True)
        return False

    def preview_unplayable(self, path, msg, auto=False):
        """GTK cannot play the file in the panel: say why, and open it in the system's video player instead."""
        self.stop_preview()
        if auto:                                                  # no windows popping up while browsing
            self.say(_("No preview could be loaded: {err}").format(err=msg))
            return
        try:
            Gio.AppInfo.launch_default_for_uri(Gio.File.new_for_path(str(path)).get_uri(), None)
            opened = True
        except GLib.Error:
            opened = False
        hint = _("GTK cannot play video here: {msg}\n\nInstall GTK's GStreamer media module and the codecs "
                 "(Debian/Ubuntu: libgtk-4-media-gstreamer gstreamer1.0-libav gstreamer1.0-plugins-good; "
                 "Fedora: gstreamer1-plugin-libav gstreamer1-plugins-good).").format(msg=msg)
        if opened:
            hint += "\n\n" + _("The video was opened in your default video player instead.")
        self.message(_("No preview could be loaded"), hint, Gtk.MessageType.WARNING)

    def find_other_video(self):
        """Throw away the stored video of the selected game and fetch a new one."""
        g = self.lib.get(self.current_id) if self.current_id else None
        if not g:
            return
        self.stop_preview()
        core.forget_preview({"path": g["path"], "title": g["title"], "video": g["video"]})
        self.toggle_preview()

    def open_videos_folder(self):
        core.VIDEO_DIR.mkdir(parents=True, exist_ok=True)
        try:
            Gio.AppInfo.launch_default_for_uri(Gio.File.new_for_path(str(core.VIDEO_DIR)).get_uri(), None)
        except GLib.Error:
            pass
        self.say(_("Put videos named like the game (e.g. Turrican II.mp4) into: {path}").format(path=core.VIDEO_DIR))

    def toggle_preview(self, auto=False):
        if self.media.get_visible_child_name() != "cover":
            self.stop_preview()
            return
        g = self.lib.get(self.current_id) if self.current_id else None
        if not g:
            return
        local = core.find_local_video(g)
        direct = (g["video"] or "").startswith("https://") and any(
            g["video"].split("?")[0].lower().endswith(e) for e in core.VIDEO_EXTS)
        if not local and not direct and not core.ytdlp_path(self.settings):
            if auto:
                return
            d = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.QUESTION,
                                  text=_("yt-dlp is needed for video previews"))
            d.format_secondary_text(_("Denise Station can download it now from the official yt-dlp releases on GitHub "
                                      "(about 3 MB, kept inside its own data folder) and keep it up to date."))
            d.add_buttons(_("Cancel"), Gtk.ResponseType.CANCEL, _("Download"), Gtk.ResponseType.YES)
            yes = d.run() == Gtk.ResponseType.YES
            d.destroy()
            if not yes:
                return
            self._pv_gen += 1
            gen = self._pv_gen
            self.pv_text.set_text(_("Downloading yt-dlp…"))
            self.pv_spin.start()
            self.media.set_visible_child_name("busy")
            self.update_pv_button()

            def dl():
                try:
                    core.download_ytdlp(cancel=lambda: gen != self._pv_gen)
                    err = ""
                except Exception as e:                           # noqa: BLE001
                    err = str(e) or type(e).__name__
                GLib.idle_add(dl_done, err)

            def dl_done(err):
                if gen != self._pv_gen:
                    return False
                self.stop_preview()
                if err:
                    self.say(_("Could not download yt-dlp: {err}").format(err=err))
                else:
                    self.toggle_preview()
                return False
            threading.Thread(target=dl, daemon=True).start()
            return
        self._pv_gen += 1
        gen = self._pv_gen
        self.pv_text.set_text(_("Looking for a video…"))
        self.pv_spin.start()
        self.media.set_visible_child_name("busy")
        self.update_pv_button()
        gd = {"path": g["path"], "title": g["title"], "video": g["video"]}

        def step(what):
            text = {"search": _("Searching YouTube for a longplay…"), "clip": _("Downloading a short clip…"), "update": _("Updating yt-dlp…")}.get(what, what)
            GLib.idle_add(lambda: (gen == self._pv_gen and self.pv_text.set_text(text), False)[1])

        def work():
            try:
                res, err = core.fetch_preview(self.settings, gd, lambda: gen != self._pv_gen, step), ""
                ar = core.video_aspect(res)
            except Exception as e:                               # noqa: BLE001 - shown to the person
                res, err, ar = None, str(e), 4 / 3
            GLib.idle_add(done, res, err, ar)

        def done(path, err, ar=4 / 3):
            if gen != self._pv_gen:
                return False
            if path is None:
                self.stop_preview()
                self.say(_("No preview could be loaded: {err}").format(err=err.splitlines()[-1] if err else ""))
                if not auto:
                    self.message(_("No preview could be loaded"), err or "?", Gtk.MessageType.WARNING)
                return False
            self.pv_spin.stop()
            ttl = core.preview_title(gd) or Path(path).name
            self.say(_("Video: {title}").format(title=ttl))
            self.pv_title.set_text(ttl)
            self.pv_title.set_tooltip_text(ttl)
            self.pv_title.set_visible(True)
            stream = Gtk.MediaFile.new_for_filename(str(path))
            if stream.get_error() is not None:                   # no media module (libgtk-4-media-gstreamer) etc.
                self.preview_unplayable(path, stream.get_error().message, auto)
                return False

            def on_error(st, _p):
                if st.get_error() is not None and gen == self._pv_gen:
                    self.preview_unplayable(path, st.get_error().message, auto)
            stream.connect("notify::error", on_error)
            stream.set_loop(True)
            self._stream = stream
            self.vid.set_size_request(DETAIL_W - 16, int((DETAIL_W - 16) / ar))   # the picture's own shape; COVER trims bars
            self.vid.set_paintable(stream)
            stream.set_muted(True)                               # silent by default; the player's own controls unmute
            self.media.set_visible_child_name("video")
            self.update_pv_button()
            stream.play()
            return False
        threading.Thread(target=work, daemon=True).start()

    def preview_cover(self):
        path = self._cover_path()
        if not path or self.current_id is None:
            return
        try:
            pb = GdkPixbuf.Pixbuf.new_from_file(path)
        except GLib.Error:
            return
        mons = Gdk.Display.get_default().get_monitors()
        geo = mons.get_item(0).get_geometry() if mons.get_n_items() else None
        sw_, sh_ = (geo.width, geo.height) if geo else (1600, 900)
        maxw, maxh = int(sw_ * 0.85), int(sh_ * 0.85)
        w, h = pb.get_width(), pb.get_height()
        k = min(maxw / w, maxh / h, 2.0)
        if abs(k - 1) > 0.001:
            pb = pb.scale_simple(max(1, int(w * k)), max(1, int(h * k)), GdkPixbuf.InterpType.BILINEAR)
        win = Gtk.Window(title=self.d_title.get_text() or "Denise Station", transient_for=self, modal=True,
                         resizable=False)
        pic = Gtk.Picture.new_for_paintable(Gdk.Texture.new_for_pixbuf(pb))
        pic.set_can_shrink(False)
        click = Gtk.GestureClick()
        click.connect("pressed", lambda *a: win.destroy())
        pic.add_controller(click)
        keys = Gtk.EventControllerKey()
        keys.connect("key-pressed", lambda c, kv, kc, st: (win.destroy(), True)[1] if kv == Gdk.KEY_Escape else False)
        win.add_controller(keys)
        win.set_child(pic)
        win.present()

    # ----------------------------------------------------------- handlers
    @dtimed("append_rows")
    def append_rows(self, a, b):
        """Add rows to the grid store (tiles start with the placeholder of their category; covers load when a tile
        scrolls into view)."""
        rows = self._rows[a:b]
        self.store.extend([[r["id"], r["title"], r["genre"], r["year"],
                            stars(r["rating"]) if r["rating"] else "", r["plays"],
                            "♥" if r["favorite"] else "", self.placeholder_thumb(r["folder"]), r["path"],
                            ("♥ " if r["favorite"] else "") + r["title"], r["folder"]] for r in rows])

    def select_row(self, idx, center=False):
        self.sel.set_selected(idx)
        try:
            self.grid.scroll_to(idx, Gtk.ListScrollFlags.NONE, None)
        except (AttributeError, TypeError):
            pass

    def on_grid_selected(self, sel, _pspec=None):
        if self._refreshing:
            return
        i = sel.get_selected()
        if i != Gtk.INVALID_LIST_POSITION:
            self.show_detail(self.store[i][0])

    # ---- thumbnails: a tile asks for its cover when it is bound (scrolls into view)
    def schedule_thumbs(self):
        return None

    def placeholder_thumb(self, folder=""):
        """Tile picture for a game without a cover, one per category (shared pixbufs, so identity checks work)."""
        src = core.placeholder_for(folder)
        if src not in self._placeholders:
            self._placeholders[src] = make_thumb(src) if src.exists() else None
        return self._placeholders[src]

    def request_thumb(self, item):
        gid = item[0]
        pb = self._tcache.get(gid)
        if pb is not None:
            self._tcache.move_to_end(gid)                    # LRU: tiles in use are dropped last
            item[7] = pb
        elif gid not in self._tpending and gid not in self._tmissing:
            self._tpending.add(gid)
            self._tpool.submit(self._thumb_worker, gid, item[8])

    def warm_thumbs(self, rows):
        """After the visible tiles are up, two background threads prepare the on-disk tiles of the whole library
        (this tab first, then everything else), so scrolling and switching tabs find them ready. Only missing
        tiles are generated; a newer list stops the old job."""
        try:
            sig = (core.SCREENS_DIR.stat().st_mtime_ns, core.EXTRAS_DIR.stat().st_mtime_ns if core.EXTRAS_DIR.exists() else 0,
                   self.lib.db.execute("SELECT COUNT(*) FROM games WHERE missing=0").fetchone()[0])
        except OSError:
            sig = None
        if sig is not None and sig == getattr(self, "_warm_done", None):
            return                                           # the whole library was already prepared
        self._warm_gen += 1
        gen = self._warm_gen
        seen = {r["id"] for r in rows}
        items = [(r["id"], r["path"]) for r in rows]
        items += [(r[0], r[1]) for r in self.lib.db.execute(
            "SELECT id, path FROM games WHERE missing=0 AND hidden=0 ORDER BY title COLLATE NOCASE") if r[0] not in seen]

        def job(part):
            try:
                os.setpriority(os.PRIO_PROCESS, threading.get_native_id(), 19)   # this thread yields to the UI
            except (OSError, AttributeError):
                pass
            time.sleep(1.0)                                  # let the visible tiles go first
            for gid, path in part:
                if gen != self._warm_gen:
                    return
                src = core.screenshot_for({"id": gid, "path": path})
                if src:
                    cached_thumb(src, only_store=True)
                time.sleep(0.001)
            finished.append(1)
            if len(finished) == 2 and gen == self._warm_gen:
                self._warm_done = sig                        # both halves finished without being interrupted
        finished = []
        parts = [items[0::2], items[1::2]]
        for part in parts:
            threading.Thread(target=job, args=(part,), daemon=True).start()

    def _thumb_worker(self, gid, path):
        src = core.screenshot_for({"id": gid, "path": path})
        pb = cached_thumb(src) if src else None
        GLib.idle_add(self._thumb_ready, gid, pb)

    @dtimed("thumb_ready")
    def _thumb_ready(self, gid, pb):
        self._tpending.discard(gid)
        if pb is None:
            self._tmissing.add(gid)                          # no picture: keep the placeholder, do not ask again
        else:
            self._tcache[gid] = pb
            while len(self._tcache) > 2000:
                self._tcache.popitem(last=False)
            item = self._bound.get(gid)
            if item is not None:
                item[7] = pb
        return False

    def show_search(self, show):
        """Show or hide the search field; hiding it clears the search."""
        if self.search_btn.get_active() != show:
            self.search_btn.set_active(show)          # re-enters here through the toggled handler
            return
        if show:
            self.search.set_visible(True)
            self.search.grab_focus()
        else:
            self.search.set_text("")
            self.search.set_visible(False)
            self.grid.grab_focus()

    def on_key(self, ctl, keyval, keycode, state):
        ctrl = state & Gdk.ModifierType.CONTROL_MASK
        if ctrl and keyval in (Gdk.KEY_f, Gdk.KEY_F):
            self.show_search(True)
            return True
        if ctrl and keyval in (Gdk.KEY_r, Gdk.KEY_R):
            self.pick_random()
            return True
        if keyval == Gdk.KEY_Escape and self.search.get_text():
            self.search.set_text("")                      # Esc clears the search (also when the focus is on the games)
            self.grid.grab_focus()
            return True
        if keyval == Gdk.KEY_Escape and self.search.get_visible():
            self.show_search(False)                       # a second Esc folds the empty field away
            return True
        if keyval == Gdk.KEY_F11 or (keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter)
                                     and state & Gtk.accelerator_get_default_mod_mask() == Gdk.ModifierType.ALT_MASK):
            self.toggle_fullscreen()                      # F11 or Alt+Enter
            return True
        if keyval == Gdk.KEY_F5:
            self.start_scan()
            return True
        return False

    def show_context_menu(self, widget, x, y):
        g = self.lib.get(self.current_id)
        if not g:
            return
        items = [(_("Play"), self.play_current),
                 (_("Remove from favorites") if g["favorite"] else _("Add to favorites"),
                  lambda: self.toggle_flag("favorite")),
                 (_("Preview video"), self.toggle_preview),
                 (_("Find another video"), self.find_other_video),
                 (_("Open the videos folder"), self.open_videos_folder),
                 None,
                 (_("Scrape"), self.scrape_current),
                 (_("Advanced scrape…"), self.advanced_scrape),
                 None,
                 ((_("Remove .desktop shortcut") if core.has_desktop(g) else _("Export .desktop shortcut…")),
                  self.remove_desktop if core.has_desktop(g) else self.export_desktop)]
        if g["last_played"]:
            items.append((_("Remove from recently played"), self.clear_recent_one))
        if self.view[0] == "recent":
            items.append((_("Clear recently played…"), self.clear_recent_all))
        items += [None, (_("Game properties…"), self.edit_current)]                 # always last
        popup_menu(widget, items, x, y)

    def export_desktop(self):
        """Add a launcher for the selected game, demo or magazine to the application menu
        (~/.local/share/applications); the icon is its cover, or the "NO COVER" picture of its category."""
        g = self.lib.get(self.current_id) if self.current_id else None
        if not g:
            return
        apps = core.applications_dir()
        cover = core.screenshot_for(g) or core.placeholder_for(g["folder"])
        try:
            apps.mkdir(parents=True, exist_ok=True)
            out = core.export_desktop(g, apps, str(cover))
        except OSError as e:
            self.message(_("Could not save"), str(e), Gtk.MessageType.WARNING)
            return
        if shutil.which("update-desktop-database"):
            subprocess.Popen(["update-desktop-database", str(apps)], stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
        self.say(_("Added to the application menu: {path}").format(path=out))

    def remove_desktop(self):
        """Delete the application-menu launcher of the selected game."""
        g = self.lib.get(self.current_id) if self.current_id else None
        if not g:
            return
        if core.remove_desktop(g):
            if shutil.which("update-desktop-database"):
                subprocess.Popen(["update-desktop-database", str(core.applications_dir())],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            self.say(_("Shortcut removed from the application menu."))
        else:
            self.message(_("Could not remove"), str(core.desktop_file(g)), Gtk.MessageType.WARNING)

    def clear_recent_one(self):
        if self.current_id and self.lib.clear_recent(self.current_id):
            self.refresh_list()
            self.say(_("Removed from recently played."))

    def clear_recent_all(self, parent=None):
        d = Gtk.MessageDialog(transient_for=parent or self, modal=True, message_type=Gtk.MessageType.QUESTION,
                              text=_("Clear the recently played list?"))
        d.format_secondary_text(_("The games stay in the library, and their play counts are kept."))
        d.add_buttons(_("Cancel"), Gtk.ResponseType.CANCEL, _("Clear"), Gtk.ResponseType.YES)
        yes = d.run() == Gtk.ResponseType.YES
        d.destroy()
        if yes:
            n = self.lib.clear_recent()
            self.refresh_list()
            self.say(_("Recently played cleared ({n} games).").format(n=n))

    def _shader_tip(self):
        cur = self.settings.get("amiberry_shader") or ""
        self.sh_btn.set_tooltip_text(_("Amiberry shader: {name} (click for the next one)").format(
            name=cur or _("as set in Amiberry")))

    def cycle_shader(self):
        order = core.SHADERS
        cur = self.settings.get("amiberry_shader") or ""
        nxt = order[(order.index(cur) + 1) % len(order)] if cur in order else order[0]
        self.settings["amiberry_shader"] = nxt
        core.save_settings(self.settings)
        self._shader_tip()
        self.say(_("Amiberry shader: {name}").format(name=nxt))

    def on_fullwindow_toggled(self, btn):
        self.settings["amiberry_fullwindow"] = btn.get_active()
        core.save_settings(self.settings)
        self.say(_("Amiberry will start in full window mode.") if btn.get_active()
                 else _("Amiberry will use its own window setting."))

    def toggle_fullscreen(self):
        if self._fullscreen:
            self.unfullscreen()
        else:
            self.fullscreen()

    def on_window_state(self, *a):
        self._fullscreen = self.is_fullscreen()
        self.fs_btn.set_icon_name("view-restore-symbolic" if self._fullscreen else "view-fullscreen-symbolic")
        self.fs_btn.set_tooltip_text((_("Exit full screen") if self._fullscreen else _("Full screen")) + " (F11)")

    def pick_random(self):
        n = len(self._rows)
        if not n:
            return
        self.select_row(random.randrange(n), center=True)
        self.grid.grab_focus()

    def toggle_flag(self, field):
        g = self.lib.get(self.current_id)
        if not g:
            return
        self.lib.update(g["id"], **{field: 0 if g[field] else 1})
        self.refresh_sidebar()
        self.refresh_list()

    def play_current(self, state=""):
        g = self.lib.get(self.current_id) if self.current_id else None
        if not g:
            return
        if not os.path.exists(g["path"]):
            self.message(_("File not found"), g["path"], Gtk.MessageType.WARNING)
            return
        if core.amiberry_missing(self.settings):
            d = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.QUESTION,
                                  text=_("Amiberry is not installed yet"))
            d.format_secondary_text(_("Denise Station can download Amiberry (AppImage) now."))
            d.add_buttons(_("Cancel"), Gtk.ResponseType.CANCEL, _("Download"), Gtk.ResponseType.YES)
            yes = d.run() == Gtk.ResponseType.YES
            d.destroy()
            if yes:
                self.install_amiberry()
            return
        if core.whdboot_missing(self.settings) and not self.fetch_whdboot():
            return
        self.stop_preview()
        core.prelaunch(self.settings, self.appearance.wants_dark())
        cmd = core.build_command(self.settings, g, state)
        core.DATA_DIR.mkdir(parents=True, exist_ok=True)
        log = open(core.LAUNCH_LOG, "wb")
        log.write((" ".join(shlex.quote(c) for c in cmd) + "\n\n").encode())
        log.flush()
        try:
            proc = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT,
                                    start_new_session=True)
        except OSError as e:
            log.close()
            self.message(_("Could not start Amiberry"),
                         _("{error}\n\nCommand: {command}").format(error=e, command=" ".join(cmd)),
                         Gtk.MessageType.ERROR)
            return
        self.lib.record_play(g["id"])
        self.say(_("Started: {title}").format(title=g["title"]))
        title = g["title"]

        def waiter():
            rc = proc.wait()
            log.close()
            GLib.idle_add(self.on_exited, title, rc)

        threading.Thread(target=waiter, daemon=True).start()
        self.refresh_list()
        self.say(_("Started: {title}").format(title=title))

    def on_exited(self, title, rc):
        if rc == 0:
            self.say(_("{title} closed.").format(title=title))
        else:
            self.say(_("Amiberry exited with code {code} for {title} - see Menu → Open last launch log.")
                     .format(code=rc, title=title))
        return False

    def open_log(self):
        if core.LAUNCH_LOG.exists():
            subprocess.Popen(["xdg-open", str(core.LAUNCH_LOG)])
        else:
            self.message(_("No log yet"), _("Launch a game first."))

    def open_scrape_log(self):
        if core.SCRAPE_LOG.exists():
            subprocess.Popen(["xdg-open", str(core.SCRAPE_LOG)])
        else:
            self.message(_("No log yet"), _("Scrape a game first."))

    # ------------------------------------------------------------ editing
    def edit_current(self):
        g = self.lib.get(self.current_id) if self.current_id else None
        if not g:
            return
        dlg = Gtk.Dialog(title=_("Game properties"), transient_for=self, modal=True)
        dlg.add_buttons(_("Cancel"), Gtk.ResponseType.CANCEL, _("Save"), Gtk.ResponseType.OK)
        dlg.set_default_size(460, -1)
        area = dlg.get_content_area()
        area.set_border_width(12)
        grid = Gtk.Grid(column_spacing=10, row_spacing=8)
        area.add(grid)

        e_title = Gtk.Entry(text=g["title"])
        c_genre = Gtk.ComboBoxText.new_with_entry()
        for name in self.lib.known_genres():
            c_genre.append_text(name)
        c_genre.get_child().set_text(g["genre"])
        if g["folder"] and self.settings["folder_categories"]:
            c_genre.set_sensitive(False)
            c_genre.set_tooltip_text(_("The category comes from the folder. Move the file to another "
                                       "folder (and rescan) to change it."))
        e_year = Gtk.Entry(text=g["year"])
        e_dev = Gtk.Entry(text=g["developer"])
        e_pub = Gtk.Entry(text=g["publisher"])
        s_rate = Gtk.SpinButton.new_with_range(0, 5, 1)
        s_rate.set_value(g["rating"])
        s_score = Gtk.SpinButton.new_with_range(0, 100, 1)       # 0 = no score; stored as 0-10 like the importer does
        s_score.set_value(round((g["score"] or 0) * 10))
        s_score.set_tooltip_text(_("Magazine-style score in percent, shown under the cover. 0 = no score."))
        try:
            old_marks = json.loads(g["marks"]) if g["marks"] else {}
        except ValueError:
            old_marks = {}
        mark_spins = {}
        for key in MARK_NAMES:
            sp = Gtk.SpinButton.new_with_range(0, 100, 1)
            sp.set_value(round(float(old_marks.get(key, 0) or 0) * 10))
            mark_spins[key] = sp
        e_args = Gtk.Entry(text=g["args"], placeholder_text=_("e.g. --model A1200"))
        tv = Gtk.TextView(wrap_mode=Gtk.WrapMode.WORD)
        tv.get_buffer().set_text(g["notes"])
        sw = Gtk.ScrolledWindow()
        sw.set_size_request(-1, 110)
        sw.add(tv)

        rows = [(_("Title"), e_title), (_("Genre"), c_genre),
                (_("Year"), e_year), (_("Developer"), e_dev),
                (_("Publisher"), e_pub), (_("Rating (0–5)"), s_rate),
                (_("Score (0–100)"), s_score),
                (_("Graphics"), mark_spins["Grafika"]), (_("Sound"), mark_spins["Dźwięk"]),
                (_("Gameplay"), mark_spins["Grywalność"]),
                (_("Atmosphere"), mark_spins["Klimat"])]
        b_cover = Gtk.Button(label=_("Set cover…"), halign=Gtk.Align.START)
        b_cover.connect("clicked", lambda b: self.set_screenshot(dlg))
        # which installed Amiberry starts this game: "Default version" or one downloaded under Amiberry versions…
        installed = core.installed_versions(self.settings)
        cur_tag = core.game_amiberry(g)
        c_ver = Gtk.ComboBoxText()
        c_ver.append("", _("Default version"))
        for t in installed + ([cur_tag] if cur_tag and cur_tag not in installed else []):
            c_ver.append(t, t if t in installed else t + " (" + _("not installed") + ")")
        c_ver.set_active_id(cur_tag)
        b_ver = Gtk.Button(label=_("Amiberry versions…"))
        b_ver.connect("clicked", lambda b: (self.manage_versions(dlg), None))
        ver_box = Gtk.Box(spacing=6)
        c_ver.set_hexpand(True)
        ver_box.append(c_ver)
        ver_box.append(b_ver)
        e_vid = Gtk.Entry(text=g["video"] or "", placeholder_text=_("Link (YouTube or a video file) or a file; empty = automatic"))
        e_vid.set_hexpand(True)
        b_vid = Gtk.Button(label=_("Choose a video…"))

        def pick_video(_b):
            fc = Gtk.FileChooserDialog(title=_("Choose a video"), transient_for=dlg, action=Gtk.FileChooserAction.OPEN)
            fc.add_buttons(_("Cancel"), Gtk.ResponseType.CANCEL, _("Open"), Gtk.ResponseType.OK)
            if fc.run() == Gtk.ResponseType.OK and fc.get_filename():
                e_vid.set_text(fc.get_filename())
            fc.destroy()
        b_vid.connect("clicked", pick_video)
        vid_box = Gtk.Box(spacing=6)
        vid_box.append(e_vid)
        vid_box.append(b_vid)
        rows += [(_("Extra Amiberry args"), e_args), (_("Amiberry version"), ver_box), (_("Cover"), b_cover),
                 (_("Video"), vid_box),
                 (_("Notes"), sw)]
        for i, (lab, w) in enumerate(rows):
            w.set_hexpand(True)
            grid.attach(Gtk.Label(label=lab, xalign=1), 0, i, 1, 1)
            grid.attach(w, 1, i, 1, 1)
        dlg.show_all()
        if dlg.run() == Gtk.ResponseType.OK:
            buf = tv.get_buffer()
            score = s_score.get_value_as_int() / 10.0
            marks = dict(old_marks)                              # other parts (from older imports) stay
            for key, sp in mark_spins.items():
                if sp.get_value_as_int():
                    marks[key] = sp.get_value_as_int() / 10.0
                else:
                    marks.pop(key, None)
            args = e_args.get_text().strip()
            rating = int(s_rate.get_value())
            if score and not rating:
                rating = max(1, min(5, round(score / 2)))        # the stars follow the score, as in the import
            self.lib.update(
                g["id"], score=score, marks=json.dumps(marks, ensure_ascii=False) if marks else "",
                title=e_title.get_text().strip() or g["title"],
                genre=c_genre.get_child().get_text().strip(), year=e_year.get_text().strip(),
                developer=e_dev.get_text().strip(), publisher=e_pub.get_text().strip(),
                rating=rating, args=args, amiberry=c_ver.get_active_id() or "", video=e_vid.get_text().strip(),
                notes=buf.get_text(buf.get_start_iter(), buf.get_end_iter(), False))
            self.refresh_sidebar()
            self.refresh_list()
        dlg.destroy()

    def set_screenshot(self, parent=None):
        g = self.lib.get(self.current_id) if self.current_id else None
        if not g:
            return
        dlg = Gtk.FileChooserDialog(title=_("Choose a cover"), transient_for=parent or self,
                                    action=Gtk.FileChooserAction.OPEN)
        dlg.add_buttons(_("Cancel"), Gtk.ResponseType.CANCEL, _("Open"), Gtk.ResponseType.OK)
        flt = Gtk.FileFilter()
        flt.set_name(_("Images"))
        for pat in ("*.png", "*.jpg", "*.jpeg"):
            flt.add_pattern(pat)
        dlg.add_filter(flt)
        if dlg.run() == Gtk.ResponseType.OK:
            src = dlg.get_filename()
            ext = os.path.splitext(src)[1].lower()
            self.clear_custom_shots(g["id"])
            shutil.copyfile(src, core.SCREENS_DIR / f"{g['id']}{ext}")
            self.show_detail(g["id"])
        dlg.destroy()

    @staticmethod
    def clear_custom_shots(gid, keep=None):
        for ext in (".png", ".jpg", ".jpeg"):
            p = core.SCREENS_DIR / f"{gid}{ext}"
            if p != keep:
                try:
                    p.unlink()
                except FileNotFoundError:
                    pass

    # ------------------------------------------------------------ scanning
    def run_wizard(self):
        """First-run wizard (also in the menu): Amiberry, WHDLoad files, ROMs, one Amiberry start to scan paths."""
        open_dl = setup_wizard.run(self)
        self.start_scan()
        if open_dl:
            whdload_dialog.open_dialog(self)
        return False

    def purge_blank_covers(self):
        """Covers saved earlier that are plain white (unpublished on OAGD) are removed, and their games are
        marked as not scraped so "Scrape" fetches them again (Libretro is tried when OAGD has no real cover)."""
        try:
            files = [f for f in core.SCREENS_DIR.iterdir() if f.suffix.lower() in (".jpg", ".jpeg", ".png")
                     and f.stem.isdigit() and f.stat().st_size < 6000]
        except OSError:
            return False
        gone = []
        for f in files:
            if is_blank_cover(f):
                try:
                    f.unlink()
                    gone.append(int(f.stem))
                except OSError:
                    pass
        if gone:
            self.lib.db.executemany("UPDATE games SET scraped=0 WHERE id=?", [(i,) for i in gone])
            self.lib.db.commit()
            self.refresh_list()
            self.say(_("Removed {n} blank covers; use Scrape to fetch them again.").format(n=len(gone)))
        return False

    def set_update_count(self, n):
        # the button is an icon now: the update count goes into its tooltip and a small badge on the icon
        self.dl_btn.set_tooltip_text(_("Download games ({n} updates)").format(n=n) if n
                                     else _("Download games") + " – " + _("WHDLoad download…"))
        if n:
            self.dl_btn.add_css_class("suggested-action")
        else:
            self.dl_btn.remove_css_class("suggested-action")
        return False

    def check_updates(self):
        """At start-up: compare your archives with the last downloaded Retroplay list (no network access)."""
        source = whdload_dialog.rp.validate_source(self.settings.get("whdload_source", ""))
        if not source or not self.settings.get("check_updates", True):
            return

        paths = [r["path"] for r in self.lib.db.execute("SELECT path FROM games WHERE missing = 0")]  # main thread

        def worker():
            try:
                entries = whdload_dialog.rp.Retroplay(source, cache_dir=core.DATA_DIR).cached_index()
                ups = whdload_dialog.rp.find_updates(paths, entries)
            except Exception:
                return
            if ups:
                GLib.idle_add(self.set_update_count, len(ups))
                GLib.idle_add(self.say, _("{count} of your WHDLoad archives have a newer version - open Download games.")
                              .format(count=len(ups)))

        threading.Thread(target=worker, daemon=True).start()

    def fetch_whdboot(self, parent=None, ask=True):
        """Download WHDLoad and the boot files with Amiberry's own --download-whdboot. True when WHDLoad is there."""
        if ask:
            d = Gtk.MessageDialog(transient_for=parent or self, modal=True, message_type=Gtk.MessageType.QUESTION,
                                  text=_("WHDLoad is not installed yet"))
            d.format_secondary_text(_("WHDLoad games need the WHDLoad program (from whdload.de), which Amiberry "
                                      "downloads separately. Download it now?"))
            d.add_buttons(_("Cancel"), Gtk.ResponseType.CANCEL, _("Download"), Gtk.ResponseType.YES)
            yes = d.run() == Gtk.ResponseType.YES
            d.destroy()
            if not yes:
                return False
        dlg = Gtk.Dialog(title=_("Download WHDLoad"), transient_for=parent or self, modal=True)
        box = dlg.get_content_area()
        box.set_border_width(16)
        box.set_spacing(10)
        box.pack_start(Gtk.Label(label=_("Downloading WHDLoad and the boot files…"), xalign=0), False, False, 0)
        bar = Gtk.ProgressBar()
        box.pack_start(bar, False, False, 0)
        res = {}

        def worker():
            res["r"] = core.download_whdboot(self.settings)
            GLib.idle_add(lambda: dlg.response(Gtk.ResponseType.OK) and False)

        pulse = GLib.timeout_add(150, lambda: bar.pulse() or True)
        threading.Thread(target=worker, daemon=True).start()
        dlg.show_all()
        dlg.run()
        GLib.source_remove(pulse)
        dlg.destroy()
        ok, out = res.get("r", (False, ""))
        if not ok:
            self.message(_("Download WHDLoad"), _("Could not download WHDLoad.\n\n{out}").format(out=out),
                         Gtk.MessageType.WARNING, parent=parent)
        elif not ask:
            self.message(_("Download WHDLoad"), _("WHDLoad and the boot files are installed."), parent=parent)
        return ok

    def open_amiberry(self):
        """Start Amiberry without a game: its own menu opens (scan ROMs, set paths, configure)."""
        if core.amiberry_missing(self.settings):
            self.message(_("Amiberry not found"), _("Use \"Download / update Amiberry\" to install it."),
                         Gtk.MessageType.WARNING)
            return
        cmd = core.base_command(self.settings)
        log = open(core.LAUNCH_LOG, "wb")
        log.write((" ".join(shlex.quote(c) for c in cmd) + "\n\n").encode())
        log.flush()
        try:
            subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        except OSError as e:
            log.close()
            self.message(_("Could not start Amiberry"), str(e), Gtk.MessageType.ERROR)

    def import_roms(self, parent=None):
        fc = Gtk.FileChooserDialog(title=_("Choose the folder with the Kickstart ROMs (e.g. Amiga Forever → Shared → rom)"),
                                   transient_for=parent or self, action=Gtk.FileChooserAction.SELECT_FOLDER)
        fc.add_buttons(_("Cancel"), Gtk.ResponseType.CANCEL, _("Import"), Gtk.ResponseType.OK)
        if fc.run() != Gtk.ResponseType.OK:
            fc.destroy()
            return
        src = fc.get_filename()
        fc.destroy()
        dest = core.roms_dir(self.settings)
        copied, same = core.import_roms(src, dest)
        if copied or same:
            self.message(_("Import Kickstart ROMs"),
                         _("Copied {n} file(s) to {path} ({same} were already there).\n\nIf Amiberry does not "
                           "find them, open its menu (F12) and press \"Rescan ROMs\" on the Play page (First-run setup).")
                         .format(n=copied, path=dest, same=same), parent=parent)
        else:
            self.message(_("Import Kickstart ROMs"), _("No Kickstart ROM files found in {path}.").format(path=src),
                         Gtk.MessageType.WARNING, parent=parent)

    def check_amiberry_update(self):
        """At start-up: when Denise installed Amiberry itself, look (once) whether a newer release exists."""
        if not core.appimage_path(self.settings):
            return False

        def worker():
            try:
                tag, newer = core.amiberry_update_info(self.settings)
            except Exception:
                return                                      # offline etc.: stay quiet
            if newer:
                GLib.idle_add(self.say, _("Amiberry {tag} is available - Settings → Download / update Amiberry.")
                              .format(tag=tag))

        threading.Thread(target=worker, daemon=True).start()
        return False

    def install_amiberry(self, parent=None):
        """Download the newest Amiberry AppImage into <game folder>/.amiberry, with a progress bar."""
        if not self.settings.get("folders"):
            self.message(_("Download / update Amiberry"), _("Add a game folder first."), parent=parent)
            return
        dlg = Gtk.Dialog(title=_("Download / update Amiberry"), transient_for=parent or self, modal=True)
        dlg.add_button(_("Cancel"), Gtk.ResponseType.CANCEL)
        box = dlg.get_content_area()
        box.set_spacing(10)
        box.set_border_width(16)
        label = Gtk.Label(label=_("Looking for the latest release…"), xalign=0, wrap=True)
        bar = Gtk.ProgressBar()
        box.pack_start(label, False, False, 0)
        box.pack_start(bar, False, False, 0)
        state = {"cancel": False}

        def show_prog(done, total):
            bar.set_fraction(done / total if total else 0.0)
            label.set_text(_("Downloading… {mb} MB").format(mb=done // 1048576))
            return False

        def worker():
            try:
                tag = core.download_appimage(self.settings, lambda d, t: GLib.idle_add(show_prog, d, t),
                                             lambda: state["cancel"])
                state["res"] = (True, tag)
            except Exception as e:
                state["res"] = (False, str(e))
            GLib.idle_add(lambda: dlg.response(Gtk.ResponseType.OK) and False)

        threading.Thread(target=worker, daemon=True).start()
        dlg.show_all()
        r = dlg.run()
        if r != Gtk.ResponseType.OK:
            state["cancel"] = True
        dlg.destroy()
        res = state.get("res")
        if r == Gtk.ResponseType.OK and res and res[0]:
            self.say(_("Amiberry {tag} installed in {path}.").format(tag=res[1], path=core.appimage_dir(self.settings)))
            if core.whdboot_missing(self.settings):
                self.fetch_whdboot(parent, ask=False)
            self.message(_("Download / update Amiberry"),
                         _("Amiberry {tag} is ready. Games start with it from now on.\n\n"
                           "Amiberry now keeps all its files (ROMs, configurations, savestates) in the "
                           "hidden .amiberry folder. Copy your Kickstart ROMs to its \"ROMs\" folder "
                           "(Settings → Open Amiberry data folder).").format(tag=res[1]), parent=parent)
        elif r == Gtk.ResponseType.OK and res:
            self.message(_("Download / update Amiberry"), _("Could not download: {err}").format(err=res[1]),
                         Gtk.MessageType.WARNING, parent=parent)

    def manage_versions(self, parent=None):
        """Window with the recent Amiberry releases: download an extra version or remove it again. A game can then
        be set to start with one of them (right click → Amiberry version)."""
        if not self.settings.get("folders"):
            self.message(_("Amiberry versions"), _("Add a game folder first."), parent=parent)
            return
        dlg = Gtk.Dialog(title=_("Amiberry versions"), transient_for=parent or self, modal=True)
        dlg.add_button(_("Close"), Gtk.ResponseType.CLOSE)
        dlg.set_default_size(620, 520)
        box = dlg.get_content_area()
        box.set_spacing(8)
        box.set_border_width(12)
        info = Gtk.Label(label=_("Looking for Amiberry releases…"), xalign=0, wrap=True)
        box.pack_start(info, False, False, 0)
        lb = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
        lb.add_css_class("boxed-list")
        sw = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER, vexpand=True)
        sw.set_child(lb)
        box.pack_start(sw, True, True, 0)
        note = Gtk.Label(wrap=True, xalign=0, use_markup=True, label="<small>%s</small>" % GLib.markup_escape_text(
            _("The default version is the one installed with \"Download / update Amiberry\". All versions share the "
              "same Amiberry files and settings, so very old or very new ones may not read each other's configurations.")))
        box.pack_start(note, False, False, 0)
        state = {"releases": [], "busy": False}

        def rebuild():
            while (r := lb.get_first_child()) is not None:
                lb.remove(r)
            default = core.appimage_version(self.settings)
            have = set(core.installed_versions(self.settings))
            rows = list(state["releases"])
            known = {core._safe_tag(r["tag"]) for r in rows}
            for tag in sorted(have):                       # installed, but older than the list shows
                if core._safe_tag(tag) not in known:
                    rows.append({"tag": tag, "date": "", "pre": False, "url": ""})
            for rel in rows:
                tag = rel["tag"]
                tag_key = core._safe_tag(tag)
                installed = tag_key in {core._safe_tag(t) for t in have}
                row = Gtk.Box(spacing=10, **mg(8))
                name = tag.split(":", 1)[-1] + ("  ·  " + _("pre-release") if rel.get("pre") else "")
                col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, hexpand=True)
                lab = Gtk.Label(label=name, xalign=0)
                col.append(lab)
                sub = "  ·  ".join(x for x in (rel.get("date", ""), rel.get("source_name", "")) if x)
                if installed:
                    sub = (sub + "  ·  " if sub else "") + (_("Default version") if tag == default else _("Installed"))
                if sub:
                    sl = Gtk.Label(label=sub, xalign=0)
                    sl.add_css_class("dim-label")
                    col.append(sl)
                row.append(col)
                if installed and tag != default:
                    b = Gtk.Button(label=_("Remove"), valign=Gtk.Align.CENTER)
                    b.connect("clicked", lambda _b, t=tag: (core.remove_version(self.settings, core._safe_tag(t)),
                                                            rebuild()))
                    row.append(b)
                elif not installed and rel.get("url"):
                    b = Gtk.Button(label=_("Download"), valign=Gtk.Align.CENTER)
                    b.connect("clicked", lambda _b, r=rel, bb=b: download(r, bb))
                    row.append(b)
                lb.append(row)

        def download(rel, btn):
            if state["busy"]:
                return
            state["busy"] = True
            btn.set_sensitive(False)

            def prog(done, total):
                btn.set_label("%d MB" % (done // 1048576))
                return False

            def worker():
                try:
                    core.download_version(self.settings, rel, lambda d, t: GLib.idle_add(prog, d, t))
                    err = ""
                except Exception as e:
                    err = str(e)
                GLib.idle_add(done_dl, err)

            def done_dl(err):
                state["busy"] = False
                if err:
                    info.set_text(_("Could not download: {err}").format(err=err))
                rebuild()
                return False
            threading.Thread(target=worker, daemon=True).start()

        def fetch():
            try:
                state["releases"], errs = core.list_releases()
                err = "; ".join(errs) if state["releases"] or errs else ""
            except Exception as e:
                err = str(e)
            GLib.idle_add(fetched, err)

        def fetched(err):
            info.set_text(_("Could not get the release list: {err}").format(err=err) if err and not state["releases"]
                          else (_("Some sources did not answer: {err}").format(err=err) if err
                                else _("Pick a version to download. Installed versions can be chosen per game.")))
            rebuild()
            return False
        rebuild()
        threading.Thread(target=fetch, daemon=True).start()
        dlg.run()
        dlg.destroy()

    def scan_and_scrape(self):
        """Rescan; when new files appeared, fetch their info and pictures (if enabled in the settings)."""
        self._scrape_after_scan = bool(self.settings.get("scrape_after_download", True))
        self.start_scan()

    def start_scan(self):
        folders = list(self.settings["folders"])
        if not folders:
            self.say(_("No game folders configured - open Menu → Settings."))
            return
        self.say(_("Scanning…"))
        exts, rec = self.settings["extensions"], self.settings["recurse"]

        def worker():
            found = core.find_games(folders, exts, rec)
            GLib.idle_add(self.scan_done, found)

        threading.Thread(target=worker, daemon=True).start()

    def scan_done(self, found):
        added, missing = self.lib.apply_scan(found, self.settings["folders"], self.settings["folder_categories"])
        self.refresh_sidebar()
        self.refresh_list()
        self.say(_("Scan finished: {found} file(s) found, {added} new, {missing} missing.")
                 .format(found=len(found), added=added, missing=missing))
        if getattr(self, "_scrape_after_scan", False):
            self._scrape_after_scan = False
            ids = self.lib.unscraped_ids()
            if ids and not self._scraping:
                self.start_scrape(ids)
        return False

    # ----------------------------------------------------------- scraping
    def make_scraper(self):
        return scraper.Scraper(cache_dir=core.DATA_DIR)

    @staticmethod
    def scrape_error_text(e):
        if isinstance(e, scraper.ServerBusy):
            return _("The Open Amiga Game Database and Libretro could not be reached. "
                     "Check your internet connection and try again later.")
        return _("Scraping error: {detail}").format(detail=e)

    def edit_amiberry_conf(self):
        """Editor for amiberry.conf: a filterable table of key=value settings, and the raw text."""
        path = core.amiberry_conf_path(self.settings)
        try:
            text = path.read_text(encoding="utf-8") if path.exists() else ""
        except OSError as e:
            self.message(_("Amiberry configuration"), _("Could not read: {err}").format(err=e.strerror or e),
                         Gtk.MessageType.WARNING)
            return
        entries = core.parse_conf(text)
        dlg = Gtk.Dialog(title=_("Amiberry configuration"), transient_for=self, modal=True)
        dlg.set_default_size(720, 600)
        dlg.add_buttons(_("Cancel"), Gtk.ResponseType.CANCEL, _("Save"), Gtk.ResponseType.OK)
        box = dlg.get_content_area()
        box.set_spacing(6)
        lab = Gtk.Label(label=str(path), xalign=0, **mg(10), selectable=True)
        lab.add_css_class("dim-label")
        box.pack_start(lab, False, False, 0)
        nb = Gtk.Notebook()
        box.pack_start(nb, True, True, 0)

        # page 1: table
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, **mg(8))
        flt = Gtk.SearchEntry(placeholder_text=_("Filter"))
        page.pack_start(flt, False, False, 0)
        store = Gtk.ListStore(str, str, int)                  # key, value, index in entries
        fmodel = store.filter_new()
        fmodel.set_visible_func(lambda m, it, d: not flt.get_text().strip()
                                or flt.get_text().strip().lower() in (m[it][0] + " " + m[it][1]).lower())
        tv = Gtk.TreeView(model=fmodel)
        tv.append_column(Gtk.TreeViewColumn(_("Key"), Gtk.CellRendererText(), text=0))
        rend = Gtk.CellRendererText(editable=True)
        col = Gtk.TreeViewColumn(_("Value"), rend, text=1)
        col.set_expand(True)
        tv.append_column(col)
        sw = Gtk.ScrolledWindow()
        sw.add(tv)
        page.pack_start(sw, True, True, 1)
        bar = Gtk.Box(spacing=6)
        b_add = Gtk.Button.new_with_label(_("Add"))
        b_del = Gtk.Button.new_with_label(_("Delete"))
        bar.pack_start(b_add, False, False, 0)
        bar.pack_start(b_del, False, False, 0)
        page.pack_start(bar, False, False, 0)
        nb.append_page(page, Gtk.Label(label=_("Table")))

        # page 2: raw text
        buf = Gtk.TextBuffer()
        tx = Gtk.TextView(buffer=buf, monospace=True, left_margin=6, right_margin=6)
        sw2 = Gtk.ScrolledWindow(**mg(8))
        sw2.add(tx)
        nb.append_page(sw2, Gtk.Label(label=_("Text")))

        def fill():
            store.clear()
            for i, e in enumerate(entries):
                if "k" in e and not e.get("deleted"):
                    store.append([e["k"], e["v"], i])

        def edited(r, path_str, new):
            row = fmodel[path_str]
            i = row[2]
            entries[i]["v"] = new.strip()
            store[fmodel.convert_path_to_child_path(Gtk.TreePath.new_from_string(path_str))][1] = new.strip()
        rend.connect("edited", edited)
        flt.connect("search-changed", lambda *a: fmodel.refilter())

        def add(*_a):
            d = Gtk.Dialog(title=_("Add"), transient_for=dlg, modal=True)
            d.add_buttons(_("Cancel"), Gtk.ResponseType.CANCEL, _("Add"), Gtk.ResponseType.OK)
            g = Gtk.Grid(column_spacing=8, row_spacing=6, **mg(12))
            ek, ev = Gtk.Entry(), Gtk.Entry()
            g.attach(Gtk.Label(label=_("Key"), xalign=0), 0, 0, 1, 1)
            g.attach(ek, 1, 0, 1, 1)
            g.attach(Gtk.Label(label=_("Value"), xalign=0), 0, 1, 1, 1)
            g.attach(ev, 1, 1, 1, 1)
            d.get_content_area().add(g)
            d.show_all()
            if d.run() == Gtk.ResponseType.OK and ek.get_text().strip():
                entries.append({"k": ek.get_text().strip(), "v": ev.get_text().strip()})
                fill()
            d.destroy()

        def delete(*_a):
            model, it = tv.get_selection().get_selected()
            if it:
                entries[model[it][2]]["deleted"] = True
                fill()
        b_add.connect("clicked", add)
        b_del.connect("clicked", delete)

        state = {"page": 0}

        def switched(nbk, pg, n):
            if n == 1 and state["page"] == 0:
                buf.set_text(core.serialize_conf(entries))
            elif n == 0 and state["page"] == 1:
                entries[:] = core.parse_conf(buf.get_text(buf.get_start_iter(), buf.get_end_iter(), False))
                fill()
            state["page"] = n
        nb.connect("switch-page", switched)
        fill()
        dlg.show_all()
        if dlg.run() == Gtk.ResponseType.OK:
            if state["page"] == 1:
                out = buf.get_text(buf.get_start_iter(), buf.get_end_iter(), False)
                out = out.rstrip("\n") + "\n"
            else:
                out = core.serialize_conf(entries)
            try:
                core.save_conf(path, out)
                self.say(_("Saved. The previous file is kept next to it as .bak."))
            except OSError as e:
                self.message(_("Amiberry configuration"), _("Could not save: {err}").format(err=e.strerror or e),
                             Gtk.MessageType.WARNING)
        dlg.destroy()

    def on_state_click(self, gesture, n, x, y):
        """Right click on a savestate in the panel: menu with Play, Rename and Delete for that row."""
        row = self.st_list.get_row_at_y(int(y))
        if row is None:
            return
        self.st_list.select_row(row)
        path = row.state_path
        popup_menu(self.st_list, [(_("Play from this savestate"), lambda: self.play_current(path)),
                                  (_("Rename…"), lambda: self.rename_state(path)),
                                  (_("Delete"), lambda: self.delete_state(path))], x, y)

    def rename_state(self, path):
        d = Gtk.Dialog(title=_("Rename…"), transient_for=self, modal=True)
        d.add_buttons(_("Cancel"), Gtk.ResponseType.CANCEL, _("Rename…"), Gtk.ResponseType.OK)
        e = Gtk.Entry(text=Path(path).stem, **mg(12), activates_default=True, width_chars=40)
        d.get_content_area().add(e)
        d.set_default_response(Gtk.ResponseType.OK)
        d.show_all()
        name = e.get_text() if d.run() == Gtk.ResponseType.OK else ""
        d.destroy()
        if not name.strip():
            return
        try:
            core.rename_savestate(path, name)
        except (ValueError, FileExistsError, OSError) as err:
            self.message(_("Savestates"), _("Could not rename: {err}").format(
                err=_("that name is not allowed or already exists") if isinstance(err, (ValueError, FileExistsError))
                else (err.strerror or err)), Gtk.MessageType.WARNING)
        self.refresh_state_list(self.lib.get(self.current_id))

    def delete_state(self, path):
        m = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.QUESTION,
                              text=_("Delete this savestate?"))
        m.format_secondary_text(Path(path).name)
        m.add_buttons(_("Cancel"), Gtk.ResponseType.CANCEL, _("Delete"), Gtk.ResponseType.YES)
        yes = m.run() == Gtk.ResponseType.YES
        m.destroy()
        if not yes:
            return
        try:
            core.delete_savestate(path)
        except OSError as err:
            self.message(_("Savestates"), _("Could not delete: {err}").format(err=err.strerror or err),
                         Gtk.MessageType.WARNING)
        self.refresh_state_list(self.lib.get(self.current_id))

    def advanced_scrape(self):
        """Edit the search text, look for candidates on OAGD and Libretro and pick the cover (and info) yourself."""
        g = self.lib.get(self.current_id) if self.current_id else None
        if g is None:
            return
        if self._scraping:
            self.say(_("A scrape is already running."))
            return
        gid = g["id"]
        query0 = core.strip_demo_word(core.lookup_title(g["title"], g["path"]), g["folder"])
        client = self.make_scraper()
        tmp = core.DATA_DIR / "pick"
        tmp.mkdir(parents=True, exist_ok=True)
        dlg = Gtk.Dialog(title=_("Advanced scrape"), transient_for=self, modal=True)
        dlg.set_default_size(760, 560)
        dlg.add_buttons(_("Cancel"), Gtk.ResponseType.CANCEL, _("Use selected"), Gtk.ResponseType.OK)
        ok_btn = dlg.get_widget_for_response(Gtk.ResponseType.OK)
        ok_btn.set_sensitive(False)
        box = dlg.get_content_area()
        box.set_spacing(8)
        row = Gtk.Box(spacing=6, **mg(10))
        entry = Gtk.Entry(text=query0, hexpand=True)
        go = Gtk.Button.new_with_label(_("Search"))
        row.pack_start(entry, True, True, 0)
        row.pack_start(go, False, False, 0)
        box.pack_start(row, False, False, 0)
        info = Gtk.Label(xalign=0, margin_start=10, margin_end=10, wrap=True)
        info.add_css_class("dim-label")
        box.pack_start(info, False, False, 0)
        view = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.SINGLE, homogeneous=True, min_children_per_line=2,
                           max_children_per_line=8, valign=Gtk.Align.START, **mg(6))
        sw = Gtk.ScrolledWindow(margin_start=10, margin_end=10, margin_bottom=10, vexpand=True)
        sw.set_child(view)
        box.pack_start(sw, True, True, 1)
        state = {"cancel": threading.Event(), "n": 0, "found": []}   # found: candidates of the current search

        def add_row(cand, pb, k, idx):
            if state["n"] == k:
                cell = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4, **mg(4))
                cell.append(Gtk.Picture.new_for_paintable(Gdk.Texture.new_for_pixbuf(pb)))
                cell.get_first_child().set_can_shrink(False)
                cell.append(Gtk.Label(label="%s\n(%s)" % (cand["name"], cand["source"]), wrap=True, max_width_chars=18,
                                      justify=Gtk.Justification.CENTER))
                cell.cand_index = idx
                view.append(cell)
            return False

        def finished(k):
            if state["n"] == k:
                n_found = len(state["found"])
                info.set_text(_("{n} results.").format(n=n_found) if n_found else _("Nothing found."))
            return False

        def search(*_a):
            state["cancel"].set()
            state["cancel"] = cancel = threading.Event()
            state["n"] += 1
            k = state["n"]
            while (c := view.get_first_child()) is not None:
                view.remove(c)
            found = state["found"] = []
            ok_btn.set_sensitive(False)
            info.set_text(_("Searching…"))
            text = entry.get_text().strip()

            def work():
                try:
                    for cand in client.candidates(text, cancel):
                        if cancel.is_set():
                            return
                        if not cand["cover_url"]:
                            continue
                        dest = client.download_image(cand["cover_url"], tmp / ("c%d_%d" % (k, len(found))))
                        if not dest or is_blank_cover(dest):
                            continue
                        pb = make_thumb(dest)
                        if pb is None:
                            continue
                        found.append(cand)
                        GLib.idle_add(add_row, cand, pb, k, len(found) - 1)
                except scraper.ScrapeError:
                    pass
                GLib.idle_add(finished, k)
            threading.Thread(target=work, daemon=True).start()

        go.connect("clicked", search)
        entry.connect("activate", search)
        view.connect("selected-children-changed", lambda v: ok_btn.set_sensitive(bool(v.get_selected_children())))
        view.connect("child-activated", lambda *a: dlg.response(Gtk.ResponseType.OK))
        dlg.show_all()
        search()
        chosen = None
        if dlg.run() == Gtk.ResponseType.OK:
            sel = view.get_selected_children()
            if sel:
                chosen = state["found"][sel[0].get_child().cand_index]
        state["cancel"].set()
        dlg.destroy()
        if not chosen:
            return
        self.say(_("Downloading the chosen cover…"))

        def apply_choice():
            shot = client.download_image(chosen["cover_url"], core.SCREENS_DIR / str(gid))
            GLib.idle_add(self.advanced_done, gid, chosen["res"], shot)
        threading.Thread(target=apply_choice, daemon=True).start()

    def advanced_done(self, gid, res, shot):
        if shot:
            self.clear_custom_shots(gid, keep=shot)
        self.lib.apply_scrape(gid, res, False, self.settings["folder_categories"])
        self._tcache.pop(gid, None)
        self.refresh_list()
        self.say(_("Cover and info updated.") if shot else _("The cover could not be downloaded."))
        return False

    def scrape_current(self):
        if self.current_id:
            self.start_scrape([self.current_id])

    def json_dialog(self, title, save):
        dlg = Gtk.FileChooserDialog(title=title, transient_for=self,
                                    action=Gtk.FileChooserAction.SAVE if save else Gtk.FileChooserAction.OPEN)
        dlg.add_buttons(_("Cancel"), Gtk.ResponseType.CANCEL, _("Save") if save else _("Open"), Gtk.ResponseType.OK)
        if save:
            dlg.set_current_name("denise-games.json")
        flt = Gtk.FileFilter()
        flt.set_name("JSON")
        flt.add_pattern("*.json")
        dlg.add_filter(flt)
        path = dlg.get_filename() if dlg.run() == Gtk.ResponseType.OK else None
        dlg.destroy()
        return path


    def import_descriptions(self):
        path = self.json_dialog(_("Choose a file with descriptions"), False)
        if not path:
            return
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list):                       # [{"key": ..., "text": ...}]
                data = {e["key"]: e.get("text") or e.get("description") or "" for e in data}
            if not isinstance(data, dict):
                raise ValueError
        except (OSError, ValueError, KeyError, TypeError):
            self.say(_("This is not a valid descriptions file."))
            return
        m = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.QUESTION,
                              text=_("Replace descriptions that games already have?"))
        m.format_secondary_text(_("Descriptions fetched from the database or typed by you are kept when you choose "
                                  "“Only empty”."))
        m.add_buttons(_("Cancel"), Gtk.ResponseType.CANCEL, _("Only empty"), Gtk.ResponseType.NO,
                      _("Replace all"), Gtk.ResponseType.YES)
        answer = m.run()
        m.destroy()
        if answer not in (Gtk.ResponseType.NO, Gtk.ResponseType.YES):
            return
        changed, unmatched = self.lib.import_descriptions(data, overwrite=answer == Gtk.ResponseType.YES)
        self.refresh_list()
        self.say(_("Descriptions added to {n} games; {m} entries matched no game.").format(n=changed, m=unmatched))

    def scrape_missing(self):
        ids = self.lib.unscraped_ids()
        if not ids:
            self.say(_("Every game has already been scraped."))
            return
        self.start_scrape(ids)

    def start_scrape(self, ids):
        if self._scraping:
            self.say(_("A scrape is already running."))
            return
        client = self.make_scraper()
        jobs = []
        skipped = 0
        for gid in ids:
            g = self.lib.get(gid)
            if g and core.no_scrape_game(g["folder"], g["path"], g["title"]):
                skipped += 1                                 # demos, beta demos and magazines: no online info
                continue
            if g:
                jobs.append({"id": gid, "path": g["path"], "title": g["title"], "query": core.strip_demo_word(core.lookup_title(g["title"], g["path"]), g["folder"]),
                             "has_shot": core.screenshot_for(g) is not None})
        if not jobs:
            if skipped:
                self.say(_("Demos, beta demos and magazines are not looked up online."))
            return
        overwrite, want_shot = self.settings["scrape_overwrite"], self.settings["scrape_screens"]
        self.cancel = threading.Event()
        cancel = self.cancel
        self._scraping = True
        self.b_stop.show()

        def worker():
            stats = {"ok": 0, "none": 0, "err": 0}
            fatal = None
            try:
                core.SCRAPE_LOG.write_text("Denise Station %s - scraping log\n" % core.VERSION)
            except OSError:
                pass
            for n, job in enumerate(jobs, 1):
                if cancel.is_set():
                    break
                GLib.idle_add(self.say, _("Scraping {n}/{total}: {title}")
                              .format(n=n, total=len(jobs), title=job["title"]))
                res, shot, outcome = None, None, "ok"
                try:
                    need_shot = want_shot and (overwrite or not job["has_shot"])
                    want_extras = False                       # back covers and manuals are no longer fetched
                    res = client.lookup(job["path"], job["query"], want_screenshot=need_shot,
                                        prefer_cover=True, want_extras=want_extras)
                    if need_shot and res.cover_url:
                        shot = client.download_image(res.cover_url,
                                                     core.SCREENS_DIR / str(job["id"]))
                        if shot and is_blank_cover(shot):
                            # OAGD sends a plain white picture for unpublished covers: drop it, ask Libretro
                            try:
                                shot.unlink()
                            except OSError:
                                pass
                            shot = None
                            client._t("  OAGD cover is blank white -> trying Libretro")
                            try:
                                lib = client.libretro_lookup(job["query"])
                                if lib.cover_url:
                                    shot = client.download_image(lib.cover_url, core.SCREENS_DIR / str(job["id"]))
                                    if shot and is_blank_cover(shot):
                                        shot.unlink()
                                        shot = None
                            except (scraper.NotFound, scraper.ScrapeError, OSError):
                                shot = None
                        if shot:
                            self.clear_custom_shots(job["id"], keep=shot)
                    extras = 0
                    if want_extras and (res.extra_images or res.manual_url):
                        extras = self.download_extras(client, job["id"], res, overwrite, cancel)
                    if not (res.genre or res.year or res.developer or res.publisher
                            or shot or extras):
                        outcome = "none"          # e.g. a Libretro match whose image was not needed
                except scraper.NotFound:
                    outcome = "none"
                except scraper.ServerBusy as e:
                    fatal = e
                    try:
                        with open(core.SCRAPE_LOG, "a", encoding="utf-8") as lf:
                            lf.write("\n" + "\n".join(client.trace) + "\nResult: server unreachable (%s)\n" % e)
                    except OSError:
                        pass
                    break
                except scraper.ScrapeError:
                    outcome = "err"
                stats[outcome] += 1
                try:
                    with open(core.SCRAPE_LOG, "a", encoding="utf-8") as lf:
                        lf.write("\n" + "\n".join(client.trace) + "\nResult: %s\n" % outcome)
                except OSError:
                    pass
                GLib.idle_add(self.on_scraped, job["id"], res, outcome, overwrite)
            GLib.idle_add(self.scrape_done, stats, fatal, cancel.is_set())

        threading.Thread(target=worker, daemon=True).start()

    @staticmethod
    def download_extras(client, gid, res, overwrite, cancel):
        """Back cover and manual into extras/<id>/. Returns how many files came."""
        folder = core.EXTRAS_DIR / str(gid)
        got = 0
        for name, url in res.extra_images[:scraper.MAX_EXTRA_IMAGES]:
            if cancel.is_set():
                break
            if not overwrite and any((folder / (name + e)).exists() for e in (".png", ".jpg")):
                continue
            got += bool(client.download_image(url, folder / name))
        if res.manual_url and not cancel.is_set() and (overwrite or not (folder / "manual.pdf").exists()):
            got += bool(client.download_manual(res.manual_url, folder / "manual"))
        return got

    def on_scraped(self, gid, res, outcome, overwrite):
        if outcome == "ok":
            self.lib.apply_scrape(gid, res, overwrite, self.settings["folder_categories"])
        elif outcome == "none":
            self.lib.mark_unmatched(gid)
        if gid == self.current_id:
            self.show_detail(gid)
        return False

    def scrape_done(self, stats, fatal, stopped):
        self._scraping = False
        self.b_stop.hide()
        self.refresh_sidebar()
        self.refresh_list()
        fmt = _("Scraping stopped: {ok} updated, {none} not found, {err} failed.") if stopped \
            else _("Scraping finished: {ok} updated, {none} not found, {err} failed.")
        self.say(fmt.format(**stats))
        if fatal is not None:
            self.message(_("Scraping"), self.scrape_error_text(fatal), Gtk.MessageType.WARNING)
        return False

    # ------------------------------------------------------------ settings
    def open_settings(self):
        s = self.settings
        dlg = Gtk.Dialog(title=_("Settings"), transient_for=self, modal=True)
        dlg.add_buttons(_("Cancel"), Gtk.ResponseType.CANCEL,
                        _("Save and scan"), Gtk.ResponseType.OK)
        dlg.set_default_size(600, 560)
        area = dlg.get_content_area()
        area.set_border_width(12)
        nb = Gtk.Notebook()
        area.pack_start(nb, True, True, 0)

        def page(title):
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, **mg(12))
            nb.append_page(box, Gtk.Label(label=title))
            return box

        def new_grid(box, rows):
            grid = Gtk.Grid(column_spacing=10, row_spacing=8)
            for i, (lab, w) in enumerate(rows):
                w.set_hexpand(True)
                grid.attach(Gtk.Label(label=lab, xalign=1), 0, i, 1, 1)
                grid.attach(w, 1, i, 1, 1)
            box.pack_start(grid, False, False, 0)
            return grid

        # ---- Library tab
        lib_box = page(_("Library"))
        lib_box.pack_start(Gtk.Label(label=bold(_("Game folder")), use_markup=True, xalign=0), False, False, 0)
        lib_box.pack_start(Gtk.Label(label=str(core.GAMES_DIR), xalign=0, selectable=True), False, False, 0)

        e_ext = Gtk.Entry(text=s["extensions"])
        e_cmd = Gtk.Entry(text=s["launch_command"],
                          placeholder_text=_("empty = the downloaded Amiberry AppImage"))
        e_args = Gtk.Entry(text=s["global_args"],
                           placeholder_text=_("extra Amiberry arguments for every game"))
        c_shader = Gtk.ComboBoxText()
        c_shader.append("", _("(leave as in Amiberry)"))
        for name in core.SHADERS:
            c_shader.append(name, name)
        c_shader.set_active_id(s.get("amiberry_shader") or "")
        c_shader.set_tooltip_text(_("Written to amiberry.conf as shader=… when a game starts."))
        c_rec = Gtk.CheckButton(label=_("Scan sub-folders"), active=s["recurse"])
        c_cat = Gtk.CheckButton(label=_("Use the sub-folder name as the category (genre)"),
                                active=s["folder_categories"])
        c_cat.set_tooltip_text(_("Games in <game folder>/Platform/ get the category \"Platform\"; "
                                 "games directly in the game folder keep their own genre."))
        grid = new_grid(lib_box, ((_("File extensions"), e_ext), (_("Launch command"), e_cmd),
                                  (_("Global arguments"), e_args), (_("Amiberry shader"), c_shader)))
        grid.attach(c_rec, 1, 4, 1, 1)
        grid.attach(c_cat, 1, 5, 1, 1)

        tools = Gtk.Box(spacing=6)
        b_data = Gtk.Button(label=_("Open Amiberry data folder"))

        def open_data(b):
            data = core.amiberry_data_dir(self.settings)
            if data.exists():
                subprocess.Popen(["xdg-open", str(data)])
            else:
                self.message(_("Not found"),
                             _("{path} does not exist yet.\nStart Amiberry once so it creates its "
                               "folders (Kickstart ROMs go there).").format(path=core.amiberry_data_dir(self.settings)),
                             parent=dlg)

        b_data.connect("clicked", open_data)
        b_inst = Gtk.Button(label=_("Download / update Amiberry"))
        b_inst.set_tooltip_text(_("Installs Amiberry (AppImage) in a hidden .amiberry folder inside your first game "
                                  "folder."))
        b_inst.connect("clicked", lambda b: self.install_amiberry(dlg))
        tools.pack_start(b_inst, False, False, 0)
        b_vers = Gtk.Button(label=_("Amiberry versions…"))
        b_vers.set_tooltip_text(_("Download other Amiberry versions; a game can then be set to use one of them."))
        b_vers.connect("clicked", lambda b: self.manage_versions(dlg))
        tools.pack_start(b_vers, False, False, 0)
        b_whd = Gtk.Button(label=_("Update WHDLoad boot files"))
        b_whd.connect("clicked", lambda b: self.fetch_whdboot(dlg, ask=False))
        tools.pack_start(b_whd, False, False, 0)
        b_rom = Gtk.Button(label=_("Import Kickstart ROMs…"))
        b_rom.set_tooltip_text(_("Copies the ROM files (and rom.key) from a folder, e.g. Amiga Forever's Shared/rom, "
                                 "into Amiberry's roms folder."))
        b_rom.connect("clicked", lambda b: self.import_roms(dlg))
        tools.pack_start(b_rom, False, False, 0)
        tools.pack_start(b_data, False, False, 0)
        lib_box.pack_start(tools, False, False, 0)
        lib_box.pack_start(Gtk.Label(
            wrap=True, xalign=0, use_markup=True,
            label="<small>%s</small>" % GLib.markup_escape_text(
                _("On save, the sandboxed Amiberry is granted read-only access to each game folder. "
                  "Amiberry still needs Kickstart ROMs of your own."))), False, False, 0)

        # ---- Scraping tab
        sc_box = page(_("Scraping"))
        sc_box.pack_start(Gtk.Label(
            wrap=True, xalign=0, use_markup=True,
            label=GLib.markup_escape_text(
                _("Fetches year, developer, publisher, genre, rating and the box cover "
                  "from the Open Amiga Game Database (openretro.org). If a game is not found there, "
                  "the cover is taken from the Libretro thumbnails, matched by similar title. "
                  "No account or login is needed.")))
            , False, False, 0)
        c_shots = Gtk.CheckButton(label=_("Also download the box cover"), active=s["scrape_screens"])
        c_over = Gtk.CheckButton(label=_("Overwrite existing info (including the title)"),
                                 active=s["scrape_overwrite"])
        sc_box.pack_start(c_shots, False, False, 0)
        sc_box.pack_start(c_over, False, False, 0)
        c_auto = Gtk.CheckButton(label=_("After a WHDLoad download, fetch info and pictures for the new games"),
                                 active=s.get("scrape_after_download", True))
        sc_box.pack_start(c_auto, False, False, 0)
        b_test = Gtk.Button(label=_("Test connection"))

        def test_conn(b):
            b.set_sensitive(False)

            def work():
                res = self.make_scraper().check()
                GLib.idle_add(done, res)

            def done(res):
                b.set_sensitive(True)
                lines = []
                for key, name in (("oagd", "Open Amiga Game Database"), ("libretro", "Libretro thumbnails")):
                    lines.append("%s: %s" % (name, _("OK") if not res.get(key)
                                             else _("not reachable ({detail})").format(detail=res[key])))
                bad = any(res.values())
                self.message(_("Connection test"), "\n".join(lines),
                             Gtk.MessageType.WARNING if bad else Gtk.MessageType.INFO, parent=dlg)
                return False

            threading.Thread(target=work, daemon=True).start()

        b_test.connect("clicked", test_conn)
        sc_box.pack_start(b_test, False, False, 0)

        # ---- General tab
        gen_box = page(_("General"))
        c_lang = Gtk.ComboBoxText()
        c_lang.append("auto", _("Automatic (system language)"))
        for code, name in i18n.available_languages().items():
            c_lang.append(code, name)
        c_lang.set_active_id(s["language"] if s["language"] in i18n.available_languages() else "auto")
        c_look = Gtk.ComboBoxText()
        c_look.append("auto", _("Automatic (follow the system)"))
        c_look.append("light", _("Light"))
        c_look.append("dark", _("Dark"))
        c_look.set_active_id(s.get("appearance", "auto") if s.get("appearance") in ("light", "dark") else "auto")
        c_look.connect("changed", lambda w: self.appearance.set_mode(w.get_active_id()))   # live preview
        e_lha = Gtk.Entry(text=s.get("lha_folder", ""), placeholder_text=str(core.amiberry_lha_folder({})))
        e_lha.set_hexpand(True)
        c_ck = Gtk.ComboBoxText()
        c_ck.append("", _("None"))
        for b_ in ("firefox", "chrome", "chromium", "brave", "edge", "opera", "vivaldi"):
            c_ck.append(b_, b_.capitalize())
        c_ck.set_active_id(s.get("ytdlp_cookies", "") if s.get("ytdlp_cookies", "") in ("firefox", "chrome", "chromium", "brave", "edge", "opera", "vivaldi") else "")
        c_auto_pv = Gtk.CheckButton(label=_("Play the video preview automatically when a game is selected"),
                                    active=s.get("preview_autoplay", True))
        c_q = Gtk.ComboBoxText()
        for h_ in (360, 480, 720, 1080):
            c_q.append(str(h_), "%dp" % h_)
        c_q.set_active_id(str(s.get("preview_height", 720)) if str(s.get("preview_height", 720)) in ("360", "480", "720", "1080") else "720")
        c_snd = Gtk.CheckButton(label=_("Also download the sound of video previews (slower)"),
                                active=s.get("preview_sound", False))
        sp_start = Gtk.SpinButton.new_with_range(0, 180, 1)
        sp_start.set_value(int(s.get("preview_start", 15)))
        e_yt = Gtk.Entry(text=s.get("ytdlp_path", ""), placeholder_text=core.ytdlp_path({}) or "yt-dlp")
        e_yt.set_hexpand(True)
        new_grid(gen_box, ((_("Language"), c_lang), (_("Appearance"), c_look),
                           (_("Amiberry LHA folder"), e_lha), (_("yt-dlp (video previews)"), e_yt),
                           (_("Preview starts at minute"), sp_start),
                           (_("Preview quality"), c_q),
                           (_("Browser cookies for YouTube"), c_ck)))
        c_warn = Gtk.CheckButton(label=_("Show the copyright notice before WHDLoad downloads"),
                                 active=s.get("whdload_warning", True))
        gen_box.pack_start(c_warn, False, False, 0)
        c_bg = Gtk.CheckButton(label=_("Retro background behind the games"), active=s.get("retro_background", True))
        gen_box.pack_start(c_bg, False, False, 0)
        c_bgs = Gtk.ComboBoxText()
        c_bgs.append("copper", _("Candy bars"))
        c_bgs.append("floppy", _("Floppy disks"))
        c_bgs.set_active_id(s.get("retro_style", "copper") if s.get("retro_style") in ("copper", "floppy") else "copper")
        new_grid(gen_box, ((_("Background style"), c_bgs),))
        gen_box.pack_start(c_auto_pv, False, False, 0)
        gen_box.pack_start(c_snd, False, False, 0)
        e_src = Gtk.Entry(text=s.get("whdload_source", ""), placeholder_text="https://")
        e_src.set_hexpand(True)
        new_grid(gen_box, ((_("Retroplay repository"), e_src),))
        c_upd = Gtk.CheckButton(label=_("Check at start-up whether newer WHDLoad archives are available"),
                                active=s.get("check_updates", True))
        gen_box.pack_start(c_upd, False, False, 0)
        gen_box.pack_start(Gtk.Label(
            wrap=True, xalign=0, use_markup=True,
            label="<small>%s</small>" % GLib.markup_escape_text(
                _("The language change takes effect after restarting Denise Station."))), False, False, 0)

        dlg.show_all()
        if dlg.run() == Gtk.ResponseType.OK:
            old_lang = s["language"]
            s["extensions"] = e_ext.get_text().strip() or core.DEFAULT_SETTINGS["extensions"]
            s["launch_command"] = e_cmd.get_text().strip()
            s["global_args"] = e_args.get_text().strip()
            s["amiberry_shader"] = c_shader.get_active_id() or ""
            s["recurse"] = c_rec.get_active()
            s["folder_categories"] = c_cat.get_active()
            s["scrape_screens"] = c_shots.get_active()
            s["scrape_overwrite"] = c_over.get_active()
            s["scrape_after_download"] = c_auto.get_active()
            s["language"] = c_lang.get_active_id() or "auto"
            s["appearance"] = c_look.get_active_id() or "auto"
            s["lha_folder"] = e_lha.get_text().strip()
            s["ytdlp_path"] = e_yt.get_text().strip()
            s["preview_start"] = sp_start.get_value_as_int()
            s["preview_autoplay"] = c_auto_pv.get_active()
            s["preview_sound"] = c_snd.get_active()
            s["preview_height"] = int(c_q.get_active_id() or 720)
            s["ytdlp_cookies"] = c_ck.get_active_id() or ""
            s["whdload_warning"] = c_warn.get_active()
            s["whdload_source"] = whdload_dialog.rp.validate_source(e_src.get_text()) if e_src.get_text().strip() else ""
            s["check_updates"] = c_upd.get_active()
            s["retro_background"] = c_bg.get_active()
            s["retro_style"] = c_bgs.get_active_id() or "copper"
            core.save_settings(s)
            self.apply_background()
            lang_changed = s["language"] != old_lang
            dlg.destroy()
            if lang_changed:
                self.message(_("Language"), _("Restart Denise Station to apply the new language."))
            self.start_scan()
        else:
            self.appearance.set_mode(self.settings.get("appearance", "auto"))   # undo the live preview
            dlg.destroy()

    # --------------------------------------------------------------- misc
    def message(self, title, text, kind=Gtk.MessageType.INFO, parent=None):
        d = Gtk.MessageDialog(transient_for=parent or self, modal=True, message_type=kind,
                              buttons=Gtk.ButtonsType.OK, text=title)
        d.format_secondary_text(text)
        d.run()
        d.destroy()


    def show_shortcuts(self):
        sections = ((_("Denise Station"), (("Ctrl+F", _("Search")),
                                           ("Esc", _("Clear the search, then hide the field")),
                                           ("Ctrl+R", _("Random game")),
                                           ("F5", _("Rescan the library")),
                                           ("F11 / Alt+Enter", _("Full screen (this program)")))),
                    (_("In Amiberry (while a game runs)"), (("F11", _("Toggle full screen / window")),
                                                            ("Esc", _("Quit the game and Amiberry")),
                                                            ("F12", _("Amiberry menu")))))
        d = Gtk.Dialog(title=_("Keyboard shortcuts"), transient_for=self, modal=True)
        d.add_button(_("Close"), Gtk.ResponseType.CLOSE)
        grid = Gtk.Grid(column_spacing=18, row_spacing=6, **mg(16))
        r = 0
        for title, rows in sections:
            lb = Gtk.Label(xalign=0)
            lb.set_markup("<b>%s</b>" % GLib.markup_escape_text(title))
            grid.attach(lb, 0, r, 2, 1)
            r += 1
            for key, text in rows:
                k = Gtk.Label(label=key, xalign=0)
                k.set_markup("<tt>%s</tt>" % GLib.markup_escape_text(key))
                grid.attach(k, 0, r, 1, 1)
                grid.attach(Gtk.Label(label=text, xalign=0), 1, r, 1, 1)
                r += 1
            r += 1
        d.get_content_area().add(grid)
        d.show_all()
        d.run()
        d.destroy()

    def show_about(self):
        d = Adw.AboutWindow(transient_for=self, modal=True)
        d.set_application_name("Denise Station")
        d.set_version(core.VERSION)
        d.set_comments(_("A clean-room Amiga game launcher that starts games in Amiberry (AppImage)."))
        icon_file = Path(__file__).resolve().parent / "assets" / "denise-station.png"
        d.set_application_icon("denise-station" if Gtk.IconTheme.get_for_display(Gdk.Display.get_default())
                               .has_icon("denise-station") else "applications-games")
        d.set_copyright(_("© Elyon") + "\n" + _("Amiga and Commodore are trademarks of their respective owners. Denise Station is an independent project, not affiliated with them."))
        d.set_developer_name("Elyon")
        d.set_developers(["Elyon <mateusz.zimniak@protonmail.com>"])
        d.set_license_type(Gtk.License.GPL_2_0)
        d.add_link(_("Amiberry website"), "https://github.com/BlitterStudio/amiberry")
        d.add_link(_("Buy Amiga Forever"), "https://www.amigaforever.com/")
        d.add_link("ppa.pl", "https://ppa.pl/")
        d.add_acknowledgement_section(_("Thanks to"), ["Amiberry https://github.com/BlitterStudio/amiberry",
                                                      "Amiga Forever (Cloanto) https://www.amigaforever.com/",
                                                      "ppa.pl https://ppa.pl/"])
        del icon_file
        d.present()


class App(Adw.Application):
    def __init__(self):
        GLib.set_prgname("local.denisestation.App")          # window class = application id = .desktop file name
        GLib.set_application_name("Denise Station")
        Gtk.Window.set_default_icon_name("denise-station")
        super().__init__(application_id="local.denisestation.App", flags=Gio.ApplicationFlags.FLAGS_NONE)

    def do_activate(self):
        win = self.props.active_window or MainWindow(self)
        win.present()


if __name__ == "__main__":
    if "--version" in sys.argv:
        print("Denise Station", core.VERSION)
        print("program:", os.path.dirname(os.path.abspath(__file__)))
        print("library:", core.DB_PATH)
        sys.exit(0)
    if "--launch" in sys.argv:                         # start one game without the window (used by .desktop shortcuts)
        i = sys.argv.index("--launch")
        if i + 1 >= len(sys.argv):
            sys.exit("usage: denise-station --launch FILE")
        sys.exit(core.launch_headless(sys.argv[i + 1]))
    start_debug()
    sys.exit(App().run([a for a in sys.argv if a != "--debug"]))
