"""Small helpers that let the GTK 3-style code of Denise Station run on GTK4 + libadwaita.

Import this module before using Gtk. It adds the few GTK3 methods the program still relies on (pack_start,
add, show_all, get_children, modal Dialog.run, FileChooser.get_filename ...) to the GTK4 classes, plus helpers
for margins and for popup menus built from plain Python lists.
"""
import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gdk, Gio, GLib, GObject, Gtk  # noqa: E402

# ------------------------------------------------------------------ plain helpers


def mg(n=0, **kw):
    """margin=N of GTK3 as keyword arguments: Gtk.Box(**mg(8))."""
    d = {"margin_top": n, "margin_bottom": n, "margin_start": n, "margin_end": n}
    d.update(kw)
    return d


class IconSize:           # GTK3 icon size constants are gone; the argument is ignored
    BUTTON = DIALOG = MENU = None


def children(widget):
    out, c = [], widget.get_first_child()
    while c is not None:
        out.append(c)
        c = c.get_next_sibling()
    return out


# ------------------------------------------------------------------ methods GTK4 removed


def _pack_start(self, child, expand=False, fill=True, padding=0):
    if expand:
        if self.get_orientation() == Gtk.Orientation.VERTICAL:
            child.set_vexpand(True)
        else:
            child.set_hexpand(True)
    self.append(child)


def _pack_end(self, child, expand=False, fill=True, padding=0):
    if expand:
        if self.get_orientation() == Gtk.Orientation.VERTICAL:
            child.set_vexpand(True)
        else:
            child.set_hexpand(True)
    self.append(child)


def _add_generic(self, child):
    if isinstance(self, Gtk.Box):
        self.append(child)
    elif isinstance(self, Gtk.Grid):
        raise TypeError("use attach()")
    elif isinstance(self, Gtk.ScrolledWindow):
        self.set_child(child)
    elif hasattr(self, "set_child"):
        self.set_child(child)
    else:
        raise TypeError("add() is not supported on %s" % type(self).__name__)


def _noop(self, *a, **k):
    return None


def _set_border_width(self, n):
    self.set_margin_top(n)
    self.set_margin_bottom(n)
    self.set_margin_start(n)
    self.set_margin_end(n)


def _dialog_run(self):
    """Modal run() for Gtk.Dialog / MessageDialog / FileChooserDialog: a nested main loop until a response."""
    loop = GLib.MainLoop()
    box = {"r": Gtk.ResponseType.NONE}

    def on_response(_d, r):
        box["r"] = r
        loop.quit()

    def on_close(_d):
        loop.quit()
        return False
    hid = self.connect("response", on_response)
    cid = self.connect("close-request", on_close)
    self.set_modal(True)
    self.present()
    loop.run()
    self.disconnect(hid)
    self.disconnect(cid)
    return box["r"]


def _filechooser_get_filename(self):
    f = self.get_file()
    return f.get_path() if f else None


def _fc_set_current_folder(orig):
    def fn(self, folder):
        if isinstance(folder, str):
            folder = Gio.File.new_for_path(folder)
        return orig(self, folder)
    return fn


def _icon_ctor(cls):
    orig = cls.new_from_icon_name

    def new(name, *_size):
        return orig(name)
    return new


def _install():
    Gtk.Box.pack_start = _pack_start
    Gtk.Box.pack_end = _pack_end
    for cls in (Gtk.Box, Gtk.ScrolledWindow, Gtk.Window, Gtk.Button, Gtk.Frame, Gtk.Viewport, Gtk.Popover):
        cls.add = _add_generic
    Gtk.Widget.show_all = _noop
    Gtk.Widget.set_no_show_all = _noop
    Gtk.Widget.set_border_width = _set_border_width
    Gtk.Widget.get_children = children
    Gtk.Container = getattr(Gtk, "Container", Gtk.Widget)
    Gtk.Dialog.run = _dialog_run
    Gtk.Dialog.get_action_area = lambda self: None
    Gtk.FileChooserDialog.get_filename = _filechooser_get_filename
    Gtk.IconSize = IconSize
    Gtk.Button.new_from_icon_name = staticmethod(_icon_ctor(Gtk.Button))
    Gtk.Image.new_from_icon_name = staticmethod(_icon_ctor(Gtk.Image))
    orig_set = Gtk.Image.set_from_icon_name
    Gtk.Image.set_from_icon_name = lambda self, name, *_s: orig_set(self, name)
    Gtk.Button.set_image = lambda self, img: self.set_child(img)
    Gtk.Button.get_image = lambda self: self.get_child()
    Gtk.Widget.get_style_context = Gtk.Widget.get_style_context  # still there; add_class works (deprecated)


_install()


# ------------------------------------------------------------------ popup menus from Python lists


def build_menu_model(items, group_name, group):
    """items: [(label, callback) | None (separator) | (label, [sub items])] -> Gio.Menu; actions go into group."""
    menu = Gio.Menu()
    section = Gio.Menu()
    n = [0]

    def add_items(target, its):
        sec = Gio.Menu()
        for it in its:
            if it is None:
                if sec.get_n_items():
                    target.append_section(None, sec)
                sec = Gio.Menu()
                continue
            label, cb = it
            if isinstance(cb, (list, tuple)):
                sub = Gio.Menu()
                add_items(sub, cb)
                sec.append_submenu(label, sub)
                continue
            n[0] += 1
            name = "a%d" % n[0]
            act = Gio.SimpleAction.new(name, None)
            act.connect("activate", lambda a, p, cb=cb: cb())
            group.add_action(act)
            sec.append(label, "%s.%s" % (group_name, name))
        if sec.get_n_items():
            target.append_section(None, sec)
    add_items(menu, items)
    del section
    return menu


def _menu_box(items, close):
    """Vertical box of flat buttons (and separators) for a Popover; sub-menus are shown as a second list."""
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0, margin_top=6, margin_bottom=6,
                  margin_start=6, margin_end=6)
    for it in items:
        if it is None:
            box.append(Gtk.Separator(margin_top=4, margin_bottom=4))
            continue
        label, cb = it
        if isinstance(cb, (list, tuple)):                       # sub-menu: its entries are listed indented
            head = Gtk.Label(label=label, xalign=0, margin_start=12, margin_top=4, margin_bottom=2,
                             css_classes=["dim-label", "caption-heading"])
            box.append(head)
            for sub in cb:
                if sub is not None:
                    box.append(_menu_button(sub[0], sub[1], close, indent=True))
            continue
        box.append(_menu_button(label, cb, close))
    return box


def _menu_button(label, cb, close, indent=False):
    b = Gtk.Button(css_classes=["flat"])
    lab = Gtk.Label(label=label, xalign=0, margin_start=18 if indent else 6, margin_end=12)
    b.set_child(lab)

    def clicked(_b):
        close()
        GLib.idle_add(lambda: (cb(), False)[1])
    b.connect("clicked", clicked)
    return b


def popup_menu(parent, items, x=None, y=None):
    """Context menu made of items (see build_menu_model), shown at (x, y) of parent, or at its centre."""
    pop = Gtk.Popover()
    pop.set_has_arrow(False)
    pop.set_autohide(True)
    pop.set_child(_menu_box(items, pop.popdown))
    pop.set_parent(parent)
    if x is not None:
        r = Gdk.Rectangle()
        r.x, r.y, r.width, r.height = int(x), int(y), 1, 1
        pop.set_pointing_to(r)
    pop.set_halign(Gtk.Align.START)
    pop.connect("closed", lambda p: GLib.idle_add(p.unparent))
    pop.popup()
    return pop


def menu_button_model(button, items, name="app"):
    """Give a Gtk.MenuButton a popover menu built from items."""
    pop = Gtk.Popover()
    pop.set_child(_menu_box(items, pop.popdown))
    button.set_popover(pop)


# MessageDialog lost format_secondary_text()
Gtk.MessageDialog.format_secondary_text = lambda self, text: self.set_property("secondary-text", text)
